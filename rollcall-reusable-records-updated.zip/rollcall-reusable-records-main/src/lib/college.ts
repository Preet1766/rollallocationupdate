import type { Tables } from "@/integrations/supabase/types";

export type Student = Tables<"students">;
export type Assignment = Tables<"roll_number_assignments">;
export type RollSettings = Tables<"roll_settings">;
export type StaffMember = Tables<"staff_allowlist">;
export type CourseRow = Tables<"courses">;
export type StudentDocument = Tables<"student_documents">;

/* ------------------------------------------------------------------ */
/* Courses, specializations, semesters                                 */
/* ------------------------------------------------------------------ */

/**
 * Fallback used until the course list loads from the database.
 * The database table `courses` is the source of truth: to add a course,
 * insert a row there (name + one digit code). See README.
 */
export const DEFAULT_COURSES: ReadonlyArray<{ name: string; code: number }> = [
  { name: "BCA", code: 0 },
  { name: "BSc", code: 1 },
  { name: "MCA", code: 7 },
];

export const SPECIALIZATIONS = [
  "Artificial Intelligence & Machine Learning",
  "Data Science",
  "Regular",
] as const;

export const SEMESTERS = [1, 2, 3, 4, 5, 6, 7, 8] as const;

export const GENDERS = ["Male", "Female", "Other"] as const;

export const DEFAULT_SETTINGS: RollSettings = {
  id: 1,
  college_name: "Sunrise College of Science & Commerce",
  updated_at: new Date(0).toISOString(),
};

/* ------------------------------------------------------------------ */
/* Roll numbers:  13 | YY | C | SSS                                    */
/* ------------------------------------------------------------------ */

export const ROLL_PREFIX = 13;

export interface RollParts {
  year: number; // full year, e.g. 2026
  courseCode: number; // 0 = BCA, 1 = BSc, 7 = MCA ...
  serial: number; // 1 - 999
}

/** Builds a roll number from its parts, e.g. (2026, 0, 1) -> 13260001. */
export function composeRoll(year: number, courseCode: number, serial: number): number {
  return ROLL_PREFIX * 1_000_000 + (year % 100) * 10_000 + courseCode * 1_000 + serial;
}

/** Splits 13260001 into { year: 2026, courseCode: 0, serial: 1 }. Null if malformed. */
export function parseRoll(roll: number | null | undefined): RollParts | null {
  if (roll === null || roll === undefined || !Number.isInteger(roll)) return null;
  if (roll < 13_000_001 || roll > 13_999_999) return null;
  const serial = roll % 1_000;
  if (serial === 0) return null;
  const courseCode = Math.floor(roll / 1_000) % 10;
  const yy = Math.floor(roll / 10_000) % 100;
  return { year: 2000 + yy, courseCode, serial };
}

/** The number shown to people. Roll numbers are plain 8-digit numbers. */
export function formatRoll(roll: number | null | undefined): string {
  if (roll === null || roll === undefined) return "—";
  return String(roll);
}

/** Free numbers are grouped by (year, course): everything before the last 3 digits. */
export function rollGroup(roll: number): number {
  return Math.floor(roll / 1_000);
}

/** Readable label for a group, e.g. 13260 -> "2026 · BCA". */
export function rollGroupLabel(
  group: number,
  courses: ReadonlyArray<{ name: string; code: number }> = DEFAULT_COURSES,
): string {
  const parts = parseRoll(group * 1_000 + 1);
  if (!parts) return String(group);
  const course = courses.find((c) => c.code === parts.courseCode);
  return `${parts.year} · ${course?.name ?? `course ${parts.courseCode}`}`;
}

/**
 * The allocation rule, written out in TypeScript.
 * The real allocation happens inside the database (see the SQL migration);
 * this mirror documents the rule and is used by the unit tests.
 * `taken` = serial numbers (1-999) held by ACTIVE students in one group.
 * Returns the lowest free serial, or null when the group is full.
 */
export function lowestFreeSerial(taken: Iterable<number>): number | null {
  const used = new Set(taken);
  const limit = Math.min(used.size + 1, 999);
  for (let serial = 1; serial <= limit; serial += 1) {
    if (!used.has(serial)) return serial;
  }
  return null;
}

/* ------------------------------------------------------------------ */
/* Dates and staff labels                                              */
/* ------------------------------------------------------------------ */

export function formatDate(value: string | null | undefined): string {
  if (!value) return "—";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleDateString(undefined, {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

export function formatDateTime(value: string | null | undefined): string {
  if (!value) return "—";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleString(undefined, {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

/** "Anita Rao (STF-014)". Older records made before staff tracking show a dash. */
export function staffLabel(
  name: string | null | undefined,
  staffId: string | null | undefined,
): string {
  if (!name) return "—";
  return staffId ? `${name} (${staffId})` : name;
}

/** First 8 characters of an account UID, for compact display. */
export function shortUid(uid: string | null | undefined): string {
  return uid ? uid.slice(0, 8) : "—";
}

/** Indian academic sessions start around July: Oct 2026 -> "2026-2027". */
export function defaultAcademicYear(now: Date = new Date()): string {
  const y = now.getFullYear();
  return now.getMonth() >= 6 ? `${y}-${y + 1}` : `${y - 1}-${y}`;
}

/* ------------------------------------------------------------------ */
/* Errors                                                              */
/* ------------------------------------------------------------------ */

/** Never surface raw database errors — map known codes to human messages. */
const ERROR_MESSAGES: Record<string, string> = {
  DUPLICATE_ADMISSION: "This admission number is already registered.",
  ADMISSION_REQUIRED: "Admission number is required.",
  NAME_REQUIRED: "Student name is required.",
  COURSE_REQUIRED: "Course is required.",
  INVALID_COURSE: "That course is not offered.",
  INVALID_ADMISSION_DATE: "Admission date must be between the years 2000 and 2099.",
  INVALID_SPECIALIZATION: "Choose one of the available specializations.",
  INVALID_SEMESTER: "Semester must be between 1 and 8.",
  INVALID_PHONE: "Enter a valid phone number (7–15 digits).",
  INVALID_EMAIL: "Enter a valid email address.",
  INVALID_DOB: "Date of birth must be in the past.",
  NO_ROLL_AVAILABLE: "No roll numbers are currently available.",
  NOT_AUTHORIZED: "You are not authorised to perform this action.",
  STUDENT_NOT_FOUND: "That student record could not be found.",
  ALREADY_CANCELLED: "This admission has already been cancelled.",
  CANCELLED_READONLY: "A cancelled admission can no longer be edited.",
  LOCKED_FIELD: "Course and admission date cannot be changed after registration.",
  LAST_ADMIN: "There must always be at least one administrator.",
  LINK_INVALID: "This upload link is no longer valid. Please ask the college office for a new one.",
  DOCUMENT_LOCKED: "This document has already been verified and cannot be replaced.",
  DOCUMENT_NOT_FOUND: "That document could not be found.",
  INVALID_DOCUMENT_TYPE: "Unknown document type.",
  INVALID_FILE_TYPE: "Only PDF, JPG or PNG files are accepted.",
  FILE_TOO_LARGE: "The file is larger than 5 MB.",
  FILE_NOT_FOUND: "The upload did not finish. Please try again.",
  INVALID_FILE_PATH: "The upload could not be linked to this student. Please try again.",
  REASON_REQUIRED: "Please give a reason when rejecting a document.",
};

export function friendlyError(error: unknown, fallback: string): string {
  const raw =
    typeof error === "object" && error !== null && "message" in error
      ? String((error as { message: unknown }).message)
      : "";
  for (const [code, message] of Object.entries(ERROR_MESSAGES)) {
    if (raw.includes(code)) return message;
  }
  if (raw.includes("duplicate key") && raw.includes("admission")) {
    return ERROR_MESSAGES["DUPLICATE_ADMISSION"]!;
  }
  if (raw.includes("Failed to fetch") || raw.includes("NetworkError")) {
    return "Unable to connect to the database. Please try again.";
  }
  return fallback;
}

/* ------------------------------------------------------------------ */
/* Student form                                                        */
/* ------------------------------------------------------------------ */

export interface StudentFormValues {
  admission_number: string;
  name: string;
  guardian_name: string;
  dob: string;
  gender: string;
  phone: string;
  email: string;
  address: string;
  course: string;
  specialization: string;
  semester: number;
  academic_year: string;
  admission_date: string;
}

/** What can still be edited after registration (course + admission date are locked). */
export type StudentEditValues = Omit<StudentFormValues, "course" | "admission_date">;

/** Shared client-side validation, mirrored by the database checks. */
export function validateStudent(
  values: Partial<StudentFormValues>,
  opts: { requireAdmission?: boolean; requireCourse?: boolean } = {},
): Record<string, string> {
  const errors: Record<string, string> = {};
  if (opts.requireAdmission !== false && !values.admission_number?.trim()) {
    errors["admission_number"] = "Admission number is required.";
  }
  if (!values.name?.trim()) errors["name"] = "Student name is required.";
  else if (values.name.trim().length > 100) errors["name"] = "Name is too long.";
  if (opts.requireCourse !== false && !values.course?.trim()) {
    errors["course"] = "Course is required.";
  }
  if (!values.semester || values.semester < 1 || values.semester > 8) {
    errors["semester"] = "Semester must be between 1 and 8.";
  }
  if (
    values.specialization !== undefined &&
    !(SPECIALIZATIONS as readonly string[]).includes(values.specialization)
  ) {
    errors["specialization"] = "Choose one of the available specializations.";
  }
  if (values.phone && !/^[+]?[\d\s-]{7,15}$/.test(values.phone.trim())) {
    errors["phone"] = "Enter a valid phone number (7–15 digits).";
  }
  if (values.email && !/^[^@\s]+@[^@\s]+\.[^@\s]{2,}$/.test(values.email.trim())) {
    errors["email"] = "Enter a valid email address.";
  }
  return errors;
}

/* ------------------------------------------------------------------ */
/* Documents                                                           */
/* ------------------------------------------------------------------ */

export const DOCUMENT_TYPES = [
  { key: "tenth_marksheet", label: "10th report card", required: true },
  { key: "twelfth_marksheet", label: "12th report card", required: true },
  { key: "aadhaar", label: "Aadhaar card", required: true },
  { key: "apaar_id", label: "APAAR ID (optional)", required: false },
  { key: "rf_form", label: "RF-3/4 form", required: true },
  { key: "character_certificate", label: "Character certificate", required: true },
  { key: "migration_certificate", label: "Migration certificate", required: true },
] as const;

export type DocumentTypeKey = (typeof DOCUMENT_TYPES)[number]["key"];

export const REQUIRED_DOCUMENT_COUNT = DOCUMENT_TYPES.filter((d) => d.required).length;

export const MAX_DOCUMENT_BYTES = 5 * 1024 * 1024;
export const ALLOWED_DOCUMENT_MIME = ["application/pdf", "image/jpeg", "image/png"] as const;

export function documentLabel(key: string): string {
  return DOCUMENT_TYPES.find((d) => d.key === key)?.label ?? key;
}

/** Returns an error message, or null when the file is acceptable. */
export function validateDocumentFile(file: { type: string; size: number }): string | null {
  if (!(ALLOWED_DOCUMENT_MIME as readonly string[]).includes(file.type)) {
    return "Only PDF, JPG or PNG files are accepted.";
  }
  if (file.size <= 0) return "That file is empty.";
  if (file.size > MAX_DOCUMENT_BYTES) return "The file is larger than 5 MB.";
  return null;
}

export interface DocumentSummary {
  verified: number; // required documents that are verified
  pending: number; // required documents uploaded, awaiting review
  rejected: number; // required documents rejected
  missing: number; // required documents not uploaded yet
  required: number;
  complete: boolean; // every required document verified
}

/** Counts only the required documents (APAAR ID never blocks completion). */
export function summariseDocuments(
  docs: ReadonlyArray<{ doc_type: string; status: string }>,
): DocumentSummary {
  const byType = new Map(docs.map((d) => [d.doc_type, d.status]));
  let verified = 0;
  let pending = 0;
  let rejected = 0;
  let missing = 0;
  for (const type of DOCUMENT_TYPES) {
    if (!type.required) continue;
    const status = byType.get(type.key);
    if (status === "verified") verified += 1;
    else if (status === "pending") pending += 1;
    else if (status === "rejected") rejected += 1;
    else missing += 1;
  }
  return {
    verified,
    pending,
    rejected,
    missing,
    required: REQUIRED_DOCUMENT_COUNT,
    complete: verified === REQUIRED_DOCUMENT_COUNT,
  };
}

/** Public link a student uses to upload documents. */
export function uploadLink(token: string, origin?: string): string {
  const base = origin ?? (typeof window !== "undefined" ? window.location.origin : "");
  return `${base}/upload/${token}`;
}
