import { describe, expect, it } from "vitest";
import {
  DOCUMENT_TYPES,
  REQUIRED_DOCUMENT_COUNT,
  composeRoll,
  defaultAcademicYear,
  formatRoll,
  friendlyError,
  lowestFreeSerial,
  parseRoll,
  rollGroup,
  rollGroupLabel,
  staffLabel,
  summariseDocuments,
  validateDocumentFile,
  validateStudent,
} from "./college";

describe("roll number format 13 | YY | C | SSS", () => {
  it("builds the first BCA roll number of 2026", () => {
    expect(composeRoll(2026, 0, 1)).toBe(13260001);
  });

  it("uses the course digit: 0 BCA, 1 BSc, 7 MCA", () => {
    expect(composeRoll(2026, 0, 5)).toBe(13260005);
    expect(composeRoll(2026, 1, 5)).toBe(13261005);
    expect(composeRoll(2026, 7, 5)).toBe(13267005);
  });

  it("uses the last two digits of the year", () => {
    expect(composeRoll(2027, 0, 1)).toBe(13270001);
  });

  it("round-trips every serial", () => {
    for (let serial = 1; serial <= 999; serial += 1) {
      expect(parseRoll(composeRoll(2026, 7, serial))).toEqual({
        year: 2026,
        courseCode: 7,
        serial,
      });
    }
  });

  it("rejects numbers that are not in the format", () => {
    expect(parseRoll(13260000)).toBeNull(); // serial 000
    expect(parseRoll(12260001)).toBeNull(); // wrong prefix
    expect(parseRoll(132600011)).toBeNull(); // too long
    expect(parseRoll(null)).toBeNull();
  });

  it("shows roll numbers as plain 8 digits", () => {
    expect(formatRoll(13260001)).toBe("13260001");
    expect(formatRoll(null)).toBe("—");
  });

  it("groups by year and course", () => {
    expect(rollGroup(13260001)).toBe(13260);
    expect(rollGroup(13260999)).toBe(13260);
    expect(rollGroup(13267001)).toBe(13267);
    expect(rollGroupLabel(13267)).toBe("2026 · MCA");
  });
});

describe("lowest-free-number allocation rule", () => {
  it("starts at 1 for an empty group", () => {
    expect(lowestFreeSerial([])).toBe(1);
  });

  it("issues sequential numbers when nothing was freed", () => {
    expect(lowestFreeSerial([1])).toBe(2);
    expect(lowestFreeSerial([1, 2, 3, 4])).toBe(5);
  });

  it("reuses a cancelled number instead of issuing a new one", () => {
    // students 1,2,3,4 and number 2 was cancelled
    expect(lowestFreeSerial([1, 3, 4])).toBe(2);
  });

  it("always picks the lowest of several free numbers", () => {
    expect(lowestFreeSerial([2, 3])).toBe(1);
    expect(lowestFreeSerial([1, 2, 4, 5, 7])).toBe(3);
  });

  it("never returns a number that is already taken", () => {
    const taken = [1, 2, 3, 5, 6, 9];
    expect(taken).not.toContain(lowestFreeSerial(taken));
  });

  it("reports a full group (999) as having no number left", () => {
    expect(lowestFreeSerial(Array.from({ length: 999 }, (_, i) => i + 1))).toBeNull();
  });
});

describe("student validation", () => {
  const valid = {
    admission_number: "ADM100",
    name: "Asha Verma",
    course: "BCA",
    semester: 1,
    specialization: "Regular",
    phone: "9876543210",
    email: "asha@example.com",
  };

  it("accepts a complete record", () => {
    expect(validateStudent(valid)).toEqual({});
  });

  it("flags missing and malformed fields", () => {
    const errors = validateStudent({
      admission_number: "",
      name: "",
      course: "",
      semester: 9,
      phone: "abc",
      email: "not-an-email",
    });
    expect(Object.keys(errors).sort()).toEqual([
      "admission_number",
      "course",
      "email",
      "name",
      "phone",
      "semester",
    ]);
  });

  it("only allows the three specializations", () => {
    expect(validateStudent({ ...valid, specialization: "Data Science" })).toEqual({});
    expect(
      validateStudent({ ...valid, specialization: "Artificial Intelligence & Machine Learning" }),
    ).toEqual({});
    expect(validateStudent({ ...valid, specialization: "Web Development" })["specialization"]).toBeDefined();
  });

  it("does not require the admission number or course when editing", () => {
    const { admission_number: _a, course: _c, ...rest } = valid;
    expect(validateStudent(rest, { requireAdmission: false, requireCourse: false })).toEqual({});
  });
});

describe("documents", () => {
  it("lists the seven documents, with only the APAAR ID optional", () => {
    expect(DOCUMENT_TYPES).toHaveLength(7);
    expect(REQUIRED_DOCUMENT_COUNT).toBe(6);
    expect(DOCUMENT_TYPES.filter((d) => !d.required).map((d) => d.key)).toEqual(["apaar_id"]);
  });

  it("counts only required documents toward completion", () => {
    const summary = summariseDocuments([
      { doc_type: "aadhaar", status: "verified" },
      { doc_type: "apaar_id", status: "verified" },
      { doc_type: "rf_form", status: "rejected" },
      { doc_type: "tenth_marksheet", status: "pending" },
    ]);
    expect(summary).toEqual({
      verified: 1,
      pending: 1,
      rejected: 1,
      missing: 3,
      required: 6,
      complete: false,
    });
  });

  it("is complete when every required document is verified, with or without APAAR", () => {
    const required = DOCUMENT_TYPES.filter((d) => d.required).map((d) => ({
      doc_type: d.key,
      status: "verified",
    }));
    expect(summariseDocuments(required).complete).toBe(true);
  });

  it("accepts PDF, JPG and PNG up to 5 MB only", () => {
    expect(validateDocumentFile({ type: "application/pdf", size: 1000 })).toBeNull();
    expect(validateDocumentFile({ type: "image/jpeg", size: 1000 })).toBeNull();
    expect(validateDocumentFile({ type: "image/png", size: 1000 })).toBeNull();
    expect(validateDocumentFile({ type: "image/gif", size: 1000 })).not.toBeNull();
    expect(validateDocumentFile({ type: "application/pdf", size: 6 * 1024 * 1024 })).not.toBeNull();
    expect(validateDocumentFile({ type: "application/pdf", size: 0 })).not.toBeNull();
  });
});

describe("messages and labels", () => {
  it("maps database codes to friendly messages", () => {
    expect(friendlyError({ message: "DUPLICATE_ADMISSION" }, "x")).toBe(
      "This admission number is already registered.",
    );
    expect(friendlyError({ message: "NO_ROLL_AVAILABLE" }, "x")).toBe(
      "No roll numbers are currently available.",
    );
    expect(friendlyError({ message: "Failed to fetch" }, "x")).toBe(
      "Unable to connect to the database. Please try again.",
    );
  });

  it("never leaks raw database errors", () => {
    expect(friendlyError({ message: 'relation "students" does not exist' }, "Something failed")).toBe(
      "Something failed",
    );
  });

  it("labels staff with name and employee id", () => {
    expect(staffLabel("Anita Rao", "STF-014")).toBe("Anita Rao (STF-014)");
    expect(staffLabel("Anita Rao", "")).toBe("Anita Rao");
    expect(staffLabel(null, null)).toBe("—");
  });

  it("starts the academic year in July", () => {
    expect(defaultAcademicYear(new Date(2026, 9, 10))).toBe("2026-2027");
    expect(defaultAcademicYear(new Date(2026, 2, 1))).toBe("2025-2026");
  });
});
