import { supabase } from "@/integrations/supabase/client";
import type {
  Assignment,
  CourseRow,
  DocumentTypeKey,
  RollSettings,
  StaffMember,
  Student,
  StudentDocument,
  StudentEditValues,
  StudentFormValues,
} from "./college";

/**
 * Data-access layer. Every call goes through the database with row-level
 * security enforced. Writes to students, roll numbers and documents only
 * happen through database functions, never by editing tables directly.
 */

export const DOCUMENT_BUCKET = "student-docs";

/* ------------------------------------------------------------------ */
/* Who is signed in                                                    */
/* ------------------------------------------------------------------ */

export interface StaffProfile {
  user_id: string;
  email: string;
  role: "admin" | "staff";
  full_name: string;
  employee_id: string;
}

/** Null when the signed-in account is not on the approved staff list. */
export async function fetchMyStaffProfile(): Promise<StaffProfile | null> {
  const { data, error } = await supabase.rpc("my_staff_profile");
  if (error) throw error;
  return data?.[0] ?? null;
}

/* ------------------------------------------------------------------ */
/* Students                                                            */
/* ------------------------------------------------------------------ */

export async function fetchStudents(): Promise<Student[]> {
  const { data, error } = await supabase
    .from("students")
    .select("*")
    .order("roll_number", { ascending: true, nullsFirst: false });
  if (error) throw error;
  return data ?? [];
}

export async function fetchStudent(id: string): Promise<Student | null> {
  const { data, error } = await supabase.from("students").select("*").eq("id", id).maybeSingle();
  if (error) throw error;
  return data;
}

export async function findByAdmissionNumber(admissionNumber: string): Promise<Student | null> {
  const { data, error } = await supabase
    .from("students")
    .select("*")
    .ilike("admission_number", admissionNumber.trim())
    .maybeSingle();
  if (error) throw error;
  return data;
}

export async function registerStudent(values: StudentFormValues): Promise<Student> {
  const { data, error } = await supabase.rpc("register_student", {
    payload: JSON.parse(JSON.stringify(values)),
  });
  if (error) throw error;
  return data as unknown as Student;
}

export async function updateStudent(
  id: string,
  values: Partial<StudentEditValues>,
): Promise<Student> {
  const { data, error } = await supabase.rpc("update_student", {
    _student_id: id,
    payload: JSON.parse(JSON.stringify(values)),
  });
  if (error) throw error;
  return data as unknown as Student;
}

export async function cancelAdmission(id: string): Promise<Student> {
  const { data, error } = await supabase.rpc("cancel_admission", { _student_id: id });
  if (error) throw error;
  return data as unknown as Student;
}

/* ------------------------------------------------------------------ */
/* Roll numbers                                                        */
/* ------------------------------------------------------------------ */

export async function fetchAssignments(): Promise<Assignment[]> {
  const { data, error } = await supabase
    .from("roll_number_assignments")
    .select("*")
    .order("assigned_at", { ascending: false });
  if (error) throw error;
  return data ?? [];
}

export async function fetchAvailableRollNumbers(): Promise<number[]> {
  const { data, error } = await supabase.rpc("available_roll_numbers");
  if (error) throw error;
  return (data ?? []).map((row) => row.roll_number).sort((a, b) => a - b);
}

/** The number a registration for this course + admission date would receive right now. */
export async function fetchNextRollNumber(
  course: string,
  admissionDate: string,
): Promise<number | null> {
  const { data, error } = await supabase.rpc("next_available_roll_number", {
    _course: course,
    _admission_date: admissionDate,
  });
  if (error) throw error;
  return data ?? null;
}

/* ------------------------------------------------------------------ */
/* Courses + settings                                                  */
/* ------------------------------------------------------------------ */

export async function fetchCourses(): Promise<CourseRow[]> {
  const { data, error } = await supabase
    .from("courses")
    .select("*")
    .eq("active", true)
    .order("sort_order", { ascending: true });
  if (error) throw error;
  return data ?? [];
}

export async function fetchSettings(): Promise<RollSettings | null> {
  const { data, error } = await supabase.from("roll_settings").select("*").eq("id", 1).maybeSingle();
  if (error) throw error;
  return data;
}

export async function updateSettings(values: { college_name: string }): Promise<RollSettings> {
  const { data, error } = await supabase
    .from("roll_settings")
    .update({ ...values, updated_at: new Date().toISOString() })
    .eq("id", 1)
    .select("*")
    .single();
  if (error) throw error;
  return data;
}

/* ------------------------------------------------------------------ */
/* Staff list (administrators only)                                    */
/* ------------------------------------------------------------------ */

export async function fetchStaffList(): Promise<StaffMember[]> {
  const { data, error } = await supabase
    .from("staff_allowlist")
    .select("*")
    .order("created_at", { ascending: true });
  if (error) throw error;
  return data ?? [];
}

export async function saveStaffMember(member: {
  email: string;
  role: "admin" | "staff";
  full_name: string;
  employee_id: string;
}): Promise<void> {
  const { error } = await supabase
    .from("staff_allowlist")
    .upsert({ ...member, email: member.email.trim().toLowerCase() }, { onConflict: "email" });
  if (error) throw error;
}

export async function removeStaffMember(email: string): Promise<void> {
  const { error } = await supabase.from("staff_allowlist").delete().eq("email", email);
  if (error) throw error;
}

/* ------------------------------------------------------------------ */
/* Documents                                                           */
/* ------------------------------------------------------------------ */

export async function fetchDocuments(studentId: string): Promise<StudentDocument[]> {
  const { data, error } = await supabase
    .from("student_documents")
    .select("*")
    .eq("student_id", studentId);
  if (error) throw error;
  return data ?? [];
}

/** One light query for the students table: which documents exist and their status. */
export async function fetchDocumentSummaries(): Promise<
  Array<Pick<StudentDocument, "student_id" | "doc_type" | "status">>
> {
  const { data, error } = await supabase
    .from("student_documents")
    .select("student_id, doc_type, status");
  if (error) throw error;
  return data ?? [];
}

function fileExtension(file: File): string {
  if (file.type === "application/pdf") return "pdf";
  if (file.type === "image/png") return "png";
  return "jpg";
}

/** Uploads into the folder named after the student's upload link. Returns the stored path. */
async function uploadToBucket(token: string, docType: DocumentTypeKey, file: File): Promise<string> {
  const path = `${token}/${docType}-${crypto.randomUUID()}.${fileExtension(file)}`;
  const { error } = await supabase.storage
    .from(DOCUMENT_BUCKET)
    .upload(path, file, { contentType: file.type, upsert: false });
  if (error) throw error;
  return path;
}

/** Staff uploading on a student's behalf (for example a student who came in person). */
export async function staffUploadDocument(
  student: Pick<Student, "id" | "upload_token">,
  docType: DocumentTypeKey,
  file: File,
): Promise<void> {
  const path = await uploadToBucket(student.upload_token, docType, file);
  const { error } = await supabase.rpc("staff_register_document", {
    _student_id: student.id,
    _doc_type: docType,
    _path: path,
    _file_name: file.name,
    _mime: file.type,
    _size: file.size,
  });
  if (error) throw error;
}

export async function verifyDocument(
  id: string,
  approve: boolean,
  reason?: string,
): Promise<StudentDocument> {
  const { data, error } = await supabase.rpc("verify_document", {
    _doc_id: id,
    _approve: approve,
    ...(reason ? { _reason: reason } : {}),
  });
  if (error) throw error;
  return data as unknown as StudentDocument;
}

/** Short-lived link (5 minutes) to open a private document. */
export async function getDocumentUrl(path: string): Promise<string> {
  const { data, error } = await supabase.storage.from(DOCUMENT_BUCKET).createSignedUrl(path, 300);
  if (error || !data) throw error ?? new Error("Unable to open document");
  return data.signedUrl;
}

export async function regenerateUploadLink(studentId: string): Promise<string> {
  const { data, error } = await supabase.rpc("regenerate_upload_link", { _student_id: studentId });
  if (error) throw error;
  return data;
}

/* ------------------------------------------------------------------ */
/* Student upload page (works with the private link only, no login)    */
/* ------------------------------------------------------------------ */

export interface PortalDocument {
  doc_type: string;
  status: "pending" | "verified" | "rejected";
  reject_reason: string | null;
  file_name: string;
  uploaded_at: string;
}

export interface PortalData {
  college_name: string | null;
  name: string;
  admission_number: string;
  course: string;
  documents: PortalDocument[];
}

/** Null when the link is invalid, replaced, or the admission was cancelled. */
export async function fetchStudentPortal(token: string): Promise<PortalData | null> {
  const { data, error } = await supabase.rpc("student_portal_get", { _token: token });
  if (error) throw error;
  return (data as unknown as PortalData | null) ?? null;
}

export async function studentUploadDocument(
  token: string,
  docType: DocumentTypeKey,
  file: File,
): Promise<void> {
  const path = await uploadToBucket(token, docType, file);
  const { error } = await supabase.rpc("student_portal_register_document", {
    _token: token,
    _doc_type: docType,
    _path: path,
    _file_name: file.name,
    _mime: file.type,
    _size: file.size,
  });
  if (error) throw error;
}
