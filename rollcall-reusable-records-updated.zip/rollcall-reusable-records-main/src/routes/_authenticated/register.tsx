import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Loader2, Search, CheckCircle2, Copy, Printer, UserPlus } from "lucide-react";
import { toast } from "sonner";
import {
  findByAdmissionNumber,
  registerStudent,
  fetchNextRollNumber,
} from "@/lib/api";
import {
  GENDERS,
  SEMESTERS,
  SPECIALIZATIONS,
  defaultAcademicYear,
  formatRoll,
  friendlyError,
  staffLabel,
  uploadLink,
  validateStudent,
  type Student,
  type StudentFormValues,
} from "@/lib/college";
import { useSettings } from "@/hooks/use-settings";
import { useCourses } from "@/hooks/use-courses";
import { PageHeader, RollChip, StatusBadge } from "@/components/portal-bits";
import { PrintableRecord } from "@/components/printable-record";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export const Route = createFileRoute("/_authenticated/register")({
  head: () => ({
    meta: [
      { title: "Register Student — College Admission Portal" },
      {
        name: "description",
        content:
          "Look up an admission number and register a new student with an automatically allocated roll number.",
      },
      { property: "og:title", content: "Register Student — College Admission Portal" },
      {
        property: "og:description",
        content: "Register admissions with automatic roll number allocation.",
      },
    ],
  }),
  component: RegisterPage,
});

const EMPTY: StudentFormValues = {
  admission_number: "",
  name: "",
  guardian_name: "",
  dob: "",
  gender: "Male",
  phone: "",
  email: "",
  address: "",
  course: "BCA",
  specialization: "Regular",
  semester: 1,
  academic_year: defaultAcademicYear(),
  admission_date: new Date().toISOString().slice(0, 10),
};

function RegisterPage() {
  const { data: settings } = useSettings();
  const queryClient = useQueryClient();
  const [step, setStep] = useState<"lookup" | "form" | "done">("lookup");
  const [existing, setExisting] = useState<Student | null>(null);
  const [created, setCreated] = useState<Student | null>(null);
  const [values, setValues] = useState<StudentFormValues>(EMPTY);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const { names: courseNames } = useCourses();

  // Preview of the number this registration would get (the real number is fixed when you save).
  const nextRoll = useQuery({
    queryKey: ["next-roll", values.course, values.admission_date],
    queryFn: () => fetchNextRollNumber(values.course, values.admission_date),
    enabled: step === "form" && Boolean(values.course) && Boolean(values.admission_date),
    retry: false,
  });

  const lookup = useMutation({
    mutationFn: (adm: string) => findByAdmissionNumber(adm),
    onSuccess: (student) => {
      if (student) {
        setExisting(student);
        setStep("lookup");
        toast.warning("Student already exists.", {
          description: `${student.name} is already registered under this admission number.`,
        });
      } else {
        setExisting(null);
        setStep("form");
      }
    },
    onError: (error) =>
      toast.error(friendlyError(error, "Unable to look up that admission number.")),
  });

  const create = useMutation({
    mutationFn: registerStudent,
    onSuccess: (student) => {
      setCreated(student);
      setStep("done");
      void queryClient.invalidateQueries();
      toast.success("Student registered successfully", {
        description: `Roll number ${formatRoll(student.roll_number)} assigned.`,
      });
    },
    onError: (error) => toast.error(friendlyError(error, "Unable to register the student.")),
  });

  function set<K extends keyof StudentFormValues>(key: K, value: StudentFormValues[K]) {
    setValues((v) => ({ ...v, [key]: value }));
    setErrors((e) => {
      const next = { ...e };
      delete next[key as string];
      return next;
    });
  }

  function handleLookup(e: React.FormEvent) {
    e.preventDefault();
    const adm = values.admission_number.trim();
    if (!adm) {
      setErrors({ admission_number: "Admission number is required." });
      return;
    }
    lookup.mutate(adm);
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const found = validateStudent(values);
    setErrors(found);
    if (Object.keys(found).length > 0) {
      toast.error("Please correct the highlighted fields.");
      return;
    }
    create.mutate(values);
  }

  function reset() {
    setValues({ ...EMPTY, admission_number: "" });
    setErrors({});
    setExisting(null);
    setCreated(null);
    setStep("lookup");
  }

  if (step === "done" && created) {
    return (
      <>
        <div className="no-print">
          <PageHeader title="Registration complete" />
          <div className="panel mx-auto max-w-2xl p-8 text-center">
            <CheckCircle2 className="mx-auto size-12 text-success" />
            <h2 className="mt-4 font-display text-2xl font-bold">
              Student Registered Successfully
            </h2>
            <p className="mt-1 text-sm text-muted-foreground">
              The roll number below was allocated automatically by the system.
            </p>

            <div className="mt-8 rounded-lg border border-primary/40 bg-accent p-6">
              <p className="label-caps">Roll Number</p>
              <p className="mt-1 font-display text-4xl font-bold text-accent-foreground">
                {formatRoll(created.roll_number)}
              </p>
            </div>

            <dl className="mt-6 grid gap-4 text-left sm:grid-cols-2">
              <Field label="Student name" value={created.name} />
              <Field label="Admission number" value={created.admission_number} />
              <Field label="Course" value={created.course} />
              <Field label="Semester" value={String(created.semester)} />
              <Field
                label="Registered by"
                value={staffLabel(created.registered_by_name, created.registered_by_staff_id)}
              />
              <Field label="Specialization" value={created.specialization} />
            </dl>

            <div className="mt-6 rounded-lg border border-border bg-surface-2 p-4 text-left">
              <p className="text-sm font-medium">Document upload link for the student</p>
              <p className="mt-1 text-xs text-muted-foreground">
                Send this private link to the student so they can upload their documents. You can
                also find it later on their profile.
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <Input
                  readOnly
                  value={uploadLink(created.upload_token)}
                  className="min-w-56 flex-1 font-mono text-xs"
                />
                <Button
                  type="button"
                  variant="secondary"
                  onClick={() => {
                    void navigator.clipboard
                      .writeText(uploadLink(created.upload_token))
                      .then(() => toast.success("Upload link copied."))
                      .catch(() => toast.error("Could not copy automatically."));
                  }}
                >
                  <Copy className="size-4" />
                  Copy
                </Button>
              </div>
            </div>

            <div className="mt-8 flex flex-wrap justify-center gap-2">
              <Button onClick={() => window.print()}>
                <Printer className="size-4" />
                Print registration details
              </Button>
              <Button variant="secondary" onClick={reset}>
                <UserPlus className="size-4" />
                Register another
              </Button>
              <Button variant="outline" asChild>
                <Link to="/students/$id" params={{ id: created.id }}>
                  View profile
                </Link>
              </Button>
            </div>
          </div>
        </div>
        <PrintableRecord student={created} settings={settings ?? null} />
      </>
    );
  }

  return (
    <>
      <PageHeader
        title="Register student"
        description="Step 1 — check the admission number. Step 2 — complete the student details. The roll number is assigned automatically."
      />

      <form onSubmit={handleLookup} className="panel mb-6 p-5">
        <Label htmlFor="adm">Admission number</Label>
        <div className="mt-2 flex flex-wrap gap-2">
          <Input
            id="adm"
            value={values.admission_number}
            onChange={(e) => set("admission_number", e.target.value)}
            placeholder="e.g. ADM005"
            className="max-w-xs"
            aria-invalid={Boolean(errors["admission_number"])}
          />
          <Button type="submit" variant="secondary" disabled={lookup.isPending}>
            {lookup.isPending ? (
              <Loader2 className="size-4 animate-spin" />
            ) : (
              <Search className="size-4" />
            )}
            Check availability
          </Button>
        </div>
        {errors["admission_number"] && (
          <p className="mt-2 text-xs text-destructive">{errors["admission_number"]}</p>
        )}
      </form>

      {existing && (
        <div className="panel mb-6 border-destructive/40 p-5">
          <p className="font-display font-bold text-destructive">Student already exists.</p>
          <dl className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Field label="Name" value={existing.name} />
            <Field label="Course" value={`${existing.course} · Sem ${existing.semester}`} />
            <Field label="Roll number" value={formatRoll(existing.roll_number)} />
            <div>
              <p className="label-caps">Status</p>
              <div className="mt-1">
                <StatusBadge status={existing.status} />
              </div>
            </div>
          </dl>
          <Button variant="outline" className="mt-4" asChild>
            <Link to="/students/$id" params={{ id: existing.id }}>
              Open student profile
            </Link>
          </Button>
        </div>
      )}

      {step === "form" && (
        <form onSubmit={handleSubmit} className="panel p-5">
          <h2 className="font-display text-lg font-bold">Student details</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Admission number <span className="font-mono">{values.admission_number}</span> is
            available.
          </p>
          <div className="mt-4 inline-flex flex-wrap items-center gap-2 rounded-md border border-primary/40 bg-accent px-3 py-2 text-sm">
            <span className="label-caps">Roll number if saved now</span>
            <RollChip>
              {nextRoll.isLoading
                ? "…"
                : nextRoll.data
                  ? formatRoll(nextRoll.data)
                  : nextRoll.isError
                    ? "unavailable"
                    : "none free"}
            </RollChip>
            <span className="text-xs text-muted-foreground">
              Depends on the course and admission date. Final number is fixed on save.
            </span>
          </div>

          <div className="mt-6 grid gap-5 md:grid-cols-2">
            <TextField
              id="name"
              label="Full name *"
              value={values.name}
              error={errors["name"]}
              onChange={(v) => set("name", v)}
            />
            <TextField
              id="guardian"
              label="Father's / Mother's / Guardian's name"
              value={values.guardian_name}
              onChange={(v) => set("guardian_name", v)}
            />
            <TextField
              id="dob"
              label="Date of birth"
              type="date"
              value={values.dob}
              onChange={(v) => set("dob", v)}
            />
            <SelectField
              label="Gender"
              value={values.gender}
              options={[...GENDERS]}
              onChange={(v) => set("gender", v)}
            />
            <TextField
              id="phone"
              label="Phone number"
              value={values.phone}
              error={errors["phone"]}
              onChange={(v) => set("phone", v)}
            />
            <TextField
              id="email"
              label="Email"
              type="email"
              value={values.email}
              error={errors["email"]}
              onChange={(v) => set("email", v)}
            />
            <SelectField
              label="Course *"
              value={values.course}
              options={courseNames}
              onChange={(v) => set("course", v)}
            />
            <SelectField
              label="Specialization"
              value={values.specialization}
              options={[...SPECIALIZATIONS]}
              onChange={(v) => set("specialization", v)}
            />
            <SelectField
              label="Semester *"
              value={String(values.semester)}
              options={SEMESTERS.map(String)}
              onChange={(v) => set("semester", Number(v))}
            />
            <TextField
              id="year"
              label="Session / academic year"
              value={values.academic_year}
              onChange={(v) => set("academic_year", v)}
            />
            <TextField
              id="admission-date"
              label="Admission date"
              type="date"
              value={values.admission_date}
              onChange={(v) => set("admission_date", v)}
            />
            <div className="md:col-span-2">
              <Label htmlFor="address">Address</Label>
              <Textarea
                id="address"
                className="mt-2"
                rows={3}
                value={values.address}
                onChange={(e) => set("address", e.target.value)}
              />
            </div>
          </div>

          <div className="mt-6 flex flex-wrap gap-2">
            <Button type="submit" disabled={create.isPending}>
              {create.isPending && <Loader2 className="size-4 animate-spin" />}
              Register &amp; assign roll number
            </Button>
            <Button type="button" variant="ghost" onClick={reset}>
              Cancel
            </Button>
          </div>
        </form>
      )}
    </>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="label-caps">{label}</p>
      <p className="mt-1 text-sm font-medium">{value || "—"}</p>
    </div>
  );
}

function TextField({
  id,
  label,
  value,
  onChange,
  type = "text",
  error,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  error?: string | undefined;
}) {
  return (
    <div>
      <Label htmlFor={id}>{label}</Label>
      <Input
        id={id}
        type={type}
        className="mt-2"
        value={value}
        aria-invalid={Boolean(error)}
        onChange={(e) => onChange(e.target.value)}
      />
      {error && <p className="mt-1 text-xs text-destructive">{error}</p>}
    </div>
  );
}

function SelectField({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: string;
  options: string[];
  onChange: (v: string) => void;
}) {
  return (
    <div>
      <Label>{label}</Label>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger className="mt-2 w-full">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {options.map((o) => (
            <SelectItem key={o} value={o}>
              {o}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
