import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { ArrowLeft, Loader2, Printer, Save, XCircle } from "lucide-react";
import { toast } from "sonner";
import { cancelAdmission, fetchStudent, updateStudent } from "@/lib/api";
import {
  GENDERS,
  SEMESTERS,
  SPECIALIZATIONS,
  formatDate,
  formatDateTime,
  formatRoll,
  friendlyError,
  parseRoll,
  rollGroupLabel,
  shortUid,
  staffLabel,
  validateStudent,
  type StudentEditValues,
} from "@/lib/college";
import { useSettings } from "@/hooks/use-settings";
import { useCourses } from "@/hooks/use-courses";
import { DocumentsPanel } from "@/components/documents-panel";
import {
  PageHeader,
  StatusBadge,
  LoadingState,
  ErrorState,
} from "@/components/portal-bits";
import { PrintableRecord } from "@/components/printable-record";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export const Route = createFileRoute("/_authenticated/students/$id")({
  head: () => ({
    meta: [
      { title: "Student Profile — College Admission Portal" },
      {
        name: "description",
        content:
          "View, edit, print or cancel a student's admission record and see their assigned roll number.",
      },
      { property: "og:title", content: "Student Profile — College Admission Portal" },
      { property: "og:description", content: "Student record and roll number details." },
    ],
  }),
  component: StudentProfile,
});

function StudentProfile() {
  const { id } = Route.useParams();
  const { data: settings } = useSettings();
  const { courses } = useCourses();
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const student = useQuery({ queryKey: ["student", id], queryFn: () => fetchStudent(id) });
  const [editing, setEditing] = useState(false);
  const [values, setValues] = useState<Partial<StudentEditValues>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});

  const save = useMutation({
    mutationFn: (payload: Partial<StudentEditValues>) => updateStudent(id, payload),
    onSuccess: () => {
      void queryClient.invalidateQueries();
      setEditing(false);
      toast.success("Student details updated.");
    },
    onError: (e) => toast.error(friendlyError(e, "Unable to update this student.")),
  });

  const cancel = useMutation({
    mutationFn: () => cancelAdmission(id),
    onSuccess: (s) => {
      void queryClient.invalidateQueries();
      toast.success("Admission cancelled", {
        description: `Roll number ${formatRoll(s.roll_number)} is now free for reuse.`,
      });
    },
    onError: (e) => toast.error(friendlyError(e, "Unable to cancel this admission.")),
  });

  if (student.isLoading) return <LoadingState label="Loading student…" />;
  if (student.isError) {
    return <ErrorState message={friendlyError(student.error, "Unable to load this student.")} />;
  }
  const s = student.data;
  if (!s) return <ErrorState message="That student record could not be found." />;

  function startEditing() {
    if (!s) return;
    setValues({
      admission_number: s.admission_number,
      name: s.name,
      guardian_name: s.guardian_name,
      dob: s.dob ?? "",
      gender: s.gender,
      phone: s.phone,
      email: s.email,
      address: s.address,
      specialization: (SPECIALIZATIONS as readonly string[]).includes(s.specialization)
        ? s.specialization
        : "Regular",
      semester: s.semester,
      academic_year: s.academic_year,
    });
    setErrors({});
    setEditing(true);
  }

  function set<K extends keyof StudentEditValues>(key: K, value: StudentEditValues[K]) {
    setValues((v) => ({ ...v, [key]: value }));
  }

  function handleSave(e: React.FormEvent) {
    e.preventDefault();
    const found = validateStudent(values, { requireCourse: false });
    setErrors(found);
    if (Object.keys(found).length > 0) {
      toast.error("Please correct the highlighted fields.");
      return;
    }
    const payload = { ...values };
    if (!payload.dob) delete payload.dob;
    save.mutate(payload);
  }

  return (
    <>
      <div className="no-print">
        <Button variant="ghost" size="sm" className="mb-3" asChild>
          <Link to="/students">
            <ArrowLeft className="size-4" />
            Back to students
          </Link>
        </Button>

        <PageHeader
          title={s.name}
          description={`Admission number ${s.admission_number}`}
          actions={
            <>
              <Button variant="secondary" onClick={() => window.print()}>
                <Printer className="size-4" />
                Print
              </Button>
              {!editing && s.status === "active" && (
                <Button variant="outline" onClick={startEditing}>
                  Edit details
                </Button>
              )}
              {s.status === "active" && (
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="destructive">
                      <XCircle className="size-4" />
                      Cancel admission
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Cancel this admission?</AlertDialogTitle>
                      <AlertDialogDescription>
                        {s.name}&apos;s roll number {formatRoll(s.roll_number)} will be
                        released and reused for the next registration. This cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Keep admission</AlertDialogCancel>
                      <AlertDialogAction onClick={() => cancel.mutate()}>
                        Cancel admission
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              )}
            </>
          }
        />

        <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
          <aside className="panel h-fit p-6 text-center">
            <p className="label-caps">Roll Number</p>
            <p className="mt-1 font-display text-4xl font-bold text-accent-foreground">
              {formatRoll(s.roll_number)}
            </p>
            {parseRoll(s.roll_number) && (
              <p className="mt-1 text-xs text-muted-foreground">
                {rollGroupLabel(Math.floor((s.roll_number ?? 0) / 1000), courses)} · serial{" "}
                {String(parseRoll(s.roll_number)?.serial).padStart(3, "0")}
              </p>
            )}
            <div className="mt-4 flex justify-center">
              <StatusBadge status={s.status} />
            </div>
            {s.status === "cancelled" && (
              <p className="mt-3 text-xs text-muted-foreground">
                Cancelled on {formatDate(s.cancelled_at)} — roll number released.
              </p>
            )}
            <dl className="mt-6 space-y-3 text-left">
              <Row label="Course" value={s.course} />
              <Row label="Specialization" value={s.specialization || "—"} />
              <Row label="Semester" value={String(s.semester)} />
              <Row label="Academic year" value={s.academic_year || "—"} />
              <Row label="Admission date" value={formatDate(s.admission_date)} />
              <Row label="Registered" value={formatDateTime(s.created_at)} />
              <div>
                <dt className="label-caps">Registered by</dt>
                <dd className="mt-1 text-sm font-medium">
                  {staffLabel(s.registered_by_name, s.registered_by_staff_id)}
                </dd>
                {s.created_by && (
                  <dd className="font-mono text-[11px] text-muted-foreground" title={s.created_by}>
                    UID {shortUid(s.created_by)}…
                  </dd>
                )}
              </div>
              {s.status === "cancelled" && (
                <div>
                  <dt className="label-caps">Cancelled by</dt>
                  <dd className="mt-1 text-sm font-medium">
                    {staffLabel(s.cancelled_by_name, s.cancelled_by_staff_id)}
                  </dd>
                  {s.cancelled_by && (
                    <dd className="font-mono text-[11px] text-muted-foreground" title={s.cancelled_by}>
                      UID {shortUid(s.cancelled_by)}…
                    </dd>
                  )}
                </div>
              )}
            </dl>
          </aside>

          {editing ? (
            <form onSubmit={handleSave} className="panel p-5">
              <h2 className="font-display text-lg font-bold">Edit student details</h2>
              <div className="mt-5 grid gap-5 md:grid-cols-2">
                <TextField
                  id="adm"
                  label="Admission number *"
                  value={values.admission_number ?? ""}
                  error={errors["admission_number"]}
                  onChange={(v) => set("admission_number", v)}
                />
                <TextField
                  id="name"
                  label="Full name *"
                  value={values.name ?? ""}
                  error={errors["name"]}
                  onChange={(v) => set("name", v)}
                />
                <TextField
                  id="guardian"
                  label="Guardian name"
                  value={values.guardian_name ?? ""}
                  onChange={(v) => set("guardian_name", v)}
                />
                <TextField
                  id="dob"
                  label="Date of birth"
                  type="date"
                  value={values.dob ?? ""}
                  onChange={(v) => set("dob", v)}
                />
                <SelectField
                  label="Gender"
                  value={values.gender ?? "Other"}
                  options={[...GENDERS]}
                  onChange={(v) => set("gender", v)}
                />
                <TextField
                  id="phone"
                  label="Phone"
                  value={values.phone ?? ""}
                  error={errors["phone"]}
                  onChange={(v) => set("phone", v)}
                />
                <TextField
                  id="email"
                  label="Email"
                  type="email"
                  value={values.email ?? ""}
                  error={errors["email"]}
                  onChange={(v) => set("email", v)}
                />
                <div className="rounded-md border border-dashed border-border p-3 md:col-span-2">
                  <p className="label-caps">Locked after registration</p>
                  <p className="mt-1 text-sm">
                    Course <span className="font-medium">{s.course}</span> · Admission date{" "}
                    <span className="font-medium">{formatDate(s.admission_date)}</span>
                  </p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    The roll number is built from these two, so they cannot be edited. If one is
                    wrong, cancel this admission and register the student again.
                  </p>
                </div>
                <SelectField
                  label="Specialization"
                  value={values.specialization ?? "Regular"}
                  options={[...SPECIALIZATIONS]}
                  onChange={(v) => set("specialization", v)}
                />
                <SelectField
                  label="Semester *"
                  value={String(values.semester ?? 1)}
                  options={SEMESTERS.map(String)}
                  onChange={(v) => set("semester", Number(v))}
                />
                <TextField
                  id="year"
                  label="Academic year"
                  value={values.academic_year ?? ""}
                  onChange={(v) => set("academic_year", v)}
                />
                <div className="md:col-span-2">
                  <Label htmlFor="address">Address</Label>
                  <Textarea
                    id="address"
                    rows={3}
                    className="mt-2"
                    value={values.address ?? ""}
                    onChange={(e) => set("address", e.target.value)}
                  />
                </div>
              </div>
              <div className="mt-6 flex gap-2">
                <Button type="submit" disabled={save.isPending}>
                  {save.isPending ? (
                    <Loader2 className="size-4 animate-spin" />
                  ) : (
                    <Save className="size-4" />
                  )}
                  Save changes
                </Button>
                <Button type="button" variant="ghost" onClick={() => setEditing(false)}>
                  Discard
                </Button>
              </div>
            </form>
          ) : (
            <section className="panel p-5">
              <h2 className="font-display text-lg font-bold">Student information</h2>
              <dl className="mt-5 grid gap-5 sm:grid-cols-2">
                <Row label="Full name" value={s.name} />
                <Row label="Guardian name" value={s.guardian_name || "—"} />
                <Row label="Date of birth" value={formatDate(s.dob)} />
                <Row label="Gender" value={s.gender} />
                <Row label="Phone" value={s.phone || "—"} />
                <Row label="Email" value={s.email || "—"} />
                <div className="sm:col-span-2">
                  <Row label="Address" value={s.address || "—"} />
                </div>
              </dl>
            </section>
          )}
        </div>

        <DocumentsPanel student={s} />

        {cancel.isSuccess && (
          <div className="mt-6">
            <Button variant="outline" onClick={() => navigate({ to: "/roll-numbers" })}>
              View roll number pool
            </Button>
          </div>
        )}
      </div>

      <PrintableRecord student={s} settings={settings ?? null} />
    </>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="label-caps">{label}</dt>
      <dd className="mt-1 text-sm font-medium">{value}</dd>
    </div>
  );
}

function TextField({
  id,
  label,
  value,
  onChange,
  type = "text",
  error,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  error?: string | undefined;
}) {
  return (
    <div>
      <Label htmlFor={id}>{label}</Label>
      <Input
        id={id}
        type={type}
        className="mt-2"
        value={value}
        aria-invalid={Boolean(error)}
        onChange={(e) => onChange(e.target.value)}
      />
      {error && <p className="mt-1 text-xs text-destructive">{error}</p>}
    </div>
  );
}

function SelectField({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: string;
  options: string[];
  onChange: (v: string) => void;
}) {
  return (
    <div>
      <Label>{label}</Label>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger className="mt-2 w-full">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {options.map((o) => (
            <SelectItem key={o} value={o}>
              {o}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
