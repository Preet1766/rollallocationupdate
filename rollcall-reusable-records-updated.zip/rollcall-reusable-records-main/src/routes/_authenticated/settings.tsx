import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { Loader2, Save } from "lucide-react";
import { toast } from "sonner";
import { updateSettings } from "@/lib/api";
import { DEFAULT_SETTINGS, friendlyError } from "@/lib/college";
import { useSettings } from "@/hooks/use-settings";
import { useStaffProfile } from "@/hooks/use-staff";
import { EmptyState, LoadingState, PageHeader } from "@/components/portal-bits";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/_authenticated/settings")({
  head: () => ({
    meta: [
      { title: "Settings — College Admission Portal" },
      {
        name: "description",
        content: "Set the college name shown on the portal and on printed registration records.",
      },
      { property: "og:title", content: "Settings — College Admission Portal" },
      { property: "og:description", content: "College settings." },
    ],
  }),
  component: SettingsPage,
});

function SettingsPage() {
  const { data, isLoading } = useSettings();
  const { isAdmin, isLoading: profileLoading } = useStaffProfile();
  const queryClient = useQueryClient();
  const [collegeName, setCollegeName] = useState(DEFAULT_SETTINGS.college_name);

  useEffect(() => {
    if (data) setCollegeName(data.college_name);
  }, [data]);

  const save = useMutation({
    mutationFn: () =>
      updateSettings({ college_name: collegeName.trim() || DEFAULT_SETTINGS.college_name }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["roll-settings"] });
      toast.success("Settings saved.");
    },
    onError: (e) => toast.error(friendlyError(e, "Unable to save settings.")),
  });

  if (isLoading || profileLoading) return <LoadingState label="Loading settings…" />;

  if (!isAdmin) {
    return (
      <>
        <PageHeader title="Settings" />
        <div className="panel">
          <EmptyState
            title="Administrators only"
            description="Only an administrator can change the portal settings."
          />
        </div>
      </>
    );
  }

  return (
    <>
      <PageHeader
        title="Settings"
        description="The college name appears in the sidebar and on printed registration records."
      />

      <form
        className="panel max-w-2xl p-5"
        onSubmit={(e) => {
          e.preventDefault();
          save.mutate();
        }}
      >
        <div className="grid gap-5">
          <div>
            <Label htmlFor="college">College name</Label>
            <Input
              id="college"
              className="mt-2"
              value={collegeName}
              maxLength={120}
              onChange={(e) => setCollegeName(e.target.value)}
            />
          </div>

          <div className="rounded-lg border border-primary/40 bg-accent p-5">
            <p className="label-caps">Roll number format (fixed)</p>
            <p className="mt-2 font-display text-3xl font-bold tracking-widest text-accent-foreground">
              13 YY C SSS
            </p>
            <ul className="mt-3 space-y-1 text-sm text-accent-foreground/90">
              <li>13 is always the same.</li>
              <li>YY is the admission year: 26 means 2026.</li>
              <li>C is the course: 0 = BCA, 1 = BSc, 7 = MCA.</li>
              <li>SSS is a serial number from 001, counted separately for each year and course.</li>
            </ul>
            <p className="mt-3 text-sm">
              Example: the first BCA student admitted in 2026 receives{" "}
              <span className="font-mono font-bold">13260001</span>.
            </p>
          </div>

          <div>
            <Button type="submit" disabled={save.isPending}>
              {save.isPending ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <Save className="size-4" />
              )}
              Save settings
            </Button>
          </div>
        </div>
      </form>
    </>
  );
}
