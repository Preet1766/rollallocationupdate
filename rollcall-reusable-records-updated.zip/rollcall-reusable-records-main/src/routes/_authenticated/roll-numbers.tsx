import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Hash, PackageOpen, RotateCcw } from "lucide-react";
import { fetchAssignments, fetchAvailableRollNumbers, fetchStudents } from "@/lib/api";
import {
  formatDate,
  formatRoll,
  friendlyError,
  rollGroup,
  rollGroupLabel,
  staffLabel,
} from "@/lib/college";
import { useCourses } from "@/hooks/use-courses";
import {
  PageHeader,
  StatCard,
  RollChip,
  LoadingState,
  EmptyState,
  ErrorState,
} from "@/components/portal-bits";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export const Route = createFileRoute("/_authenticated/roll-numbers")({
  head: () => ({
    meta: [
      { title: "Roll Numbers — College Admission Portal" },
      {
        name: "description",
        content:
          "Track every roll number assignment and release, and see which roll numbers are free for reuse.",
      },
      { property: "og:title", content: "Roll Numbers — College Admission Portal" },
      {
        property: "og:description",
        content: "Roll number allocation history and the pool of free numbers.",
      },
    ],
  }),
  component: RollNumbersPage,
});

function RollNumbersPage() {
  const { courses } = useCourses();
  const assignments = useQuery({ queryKey: ["assignments"], queryFn: fetchAssignments });
  const available = useQuery({ queryKey: ["available-rolls"], queryFn: fetchAvailableRollNumbers });
  const students = useQuery({ queryKey: ["students"], queryFn: fetchStudents });

  const nameById = new Map((students.data ?? []).map((s) => [s.id, s]));
  const history = assignments.data ?? [];
  const free = available.data ?? [];
  const releasedCount = history.filter((a) => a.status === "released").length;

  // Free numbers grouped by year + course; the lowest in each group is issued next.
  const freeGroups = new Map<number, number[]>();
  for (const n of free) {
    const g = rollGroup(n);
    freeGroups.set(g, [...(freeGroups.get(g) ?? []), n]);
  }
  const orderedGroups = [...freeGroups.entries()].sort((a, b) => a[0] - b[0]);

  return (
    <>
      <PageHeader
        title="Roll numbers"
        description="Format 13 · year · course · serial. Numbers are allocated automatically, and freed numbers are always reused before a new one is issued."
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="Total allocations" value={history.length} icon={Hash} />
        <StatCard label="Released / reusable" value={releasedCount} icon={RotateCcw} tone="destructive" />
        <StatCard
          label="Available in pool"
          value={free.length}
          icon={PackageOpen}
          tone="primary"
        />
      </div>

      <section className="panel mt-6 p-5">
        <h2 className="font-display text-base font-bold">Available roll number pool</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          These numbers were freed by cancelled admissions. Within each year and course, the lowest
          one is given to the next student.
        </p>
        {free.length === 0 ? (
          <p className="mt-4 text-sm text-muted-foreground">
            No free roll numbers — the next registration in any group receives the next serial
            number.
          </p>
        ) : (
          <div className="mt-4 space-y-4">
            {orderedGroups.map(([group, numbers]) => (
              <div key={group}>
                <p className="label-caps mb-2">{rollGroupLabel(group, courses)}</p>
                <div className="flex flex-wrap gap-2">
                  {numbers.map((n, i) => (
                    <span
                      key={n}
                      className={
                        i === 0
                          ? "inline-flex rounded-md bg-primary px-2.5 py-1 font-mono text-xs font-bold text-primary-foreground"
                          : "inline-flex rounded-md border border-primary/40 bg-accent px-2.5 py-1 font-mono text-xs font-bold text-accent-foreground"
                      }
                    >
                      {formatRoll(n)}
                      {i === 0 && " · next"}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="panel mt-6 overflow-hidden">
        <header className="border-b border-border px-5 py-4">
          <h2 className="font-display text-base font-bold">Assignment history</h2>
        </header>
        {assignments.isLoading ? (
          <LoadingState label="Loading history…" />
        ) : assignments.isError ? (
          <ErrorState message={friendlyError(assignments.error, "Unable to load history.")} />
        ) : history.length === 0 ? (
          <EmptyState
            title="No assignments yet"
            description="Roll number allocations appear here as students are registered."
          />
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Roll no.</TableHead>
                  <TableHead>Student</TableHead>
                  <TableHead>Admission no.</TableHead>
                  <TableHead>Assigned</TableHead>
                  <TableHead>Assigned by</TableHead>
                  <TableHead>Released</TableHead>
                  <TableHead>Released by</TableHead>
                  <TableHead>State</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {history.map((a) => {
                  const student = nameById.get(a.student_id);
                  return (
                    <TableRow key={a.id}>
                      <TableCell>
                        <RollChip>{formatRoll(a.roll_number)}</RollChip>
                      </TableCell>
                      <TableCell className="font-medium">{student?.name ?? "—"}</TableCell>
                      <TableCell className="font-mono text-xs">
                        {student?.admission_number ?? "—"}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {formatDate(a.assigned_at)}
                      </TableCell>
                      <TableCell className="text-sm" title={a.assigned_by ?? undefined}>
                        {staffLabel(a.assigned_by_name, a.assigned_by_staff_id)}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {formatDate(a.released_at)}
                      </TableCell>
                      <TableCell className="text-sm" title={a.released_by ?? undefined}>
                        {staffLabel(a.released_by_name, a.released_by_staff_id)}
                      </TableCell>
                      <TableCell>
                        <span
                          className={
                            a.status === "assigned"
                              ? "inline-flex rounded-full border border-success/40 bg-success/10 px-2.5 py-0.5 text-xs font-semibold text-success"
                              : "inline-flex rounded-full border border-destructive/40 bg-destructive/10 px-2.5 py-0.5 text-xs font-semibold text-destructive"
                          }
                        >
                          {a.status === "assigned" ? "Assigned" : "Released"}
                        </span>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </section>
    </>
  );
}
