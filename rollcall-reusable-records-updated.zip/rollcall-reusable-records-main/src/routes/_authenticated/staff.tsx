import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Loader2, Pencil, Save, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { fetchStaffList, removeStaffMember, saveStaffMember } from "@/lib/api";
import { formatDate, friendlyError, type StaffMember } from "@/lib/college";
import { useStaffProfile } from "@/hooks/use-staff";
import { EmptyState, ErrorState, LoadingState, PageHeader } from "@/components/portal-bits";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export const Route = createFileRoute("/_authenticated/staff")({
  head: () => ({
    meta: [
      { title: "Staff — College Admission Portal" },
      {
        name: "description",
        content: "Administrators approve staff emails, set names and employee IDs, and assign roles.",
      },
    ],
  }),
  component: StaffPage,
});

interface FormState {
  email: string;
  full_name: string;
  employee_id: string;
  role: "admin" | "staff";
}

const EMPTY: FormState = { email: "", full_name: "", employee_id: "", role: "staff" };

function StaffPage() {
  const { profile, isAdmin, isLoading } = useStaffProfile();
  const queryClient = useQueryClient();
  const [form, setForm] = useState<FormState>(EMPTY);
  const [editingEmail, setEditingEmail] = useState<string | null>(null);

  const list = useQuery({ queryKey: ["staff-list"], queryFn: fetchStaffList, enabled: isAdmin });

  const save = useMutation({
    mutationFn: () => saveStaffMember({ ...form, full_name: form.full_name.trim(), employee_id: form.employee_id.trim() }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["staff-list"] });
      void queryClient.invalidateQueries({ queryKey: ["staff-profile"] });
      toast.success(editingEmail ? "Staff member updated." : "Staff member approved.");
      setForm(EMPTY);
      setEditingEmail(null);
    },
    onError: (e) => toast.error(friendlyError(e, "Unable to save this staff member.")),
  });

  const remove = useMutation({
    mutationFn: (email: string) => removeStaffMember(email),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["staff-list"] });
      toast.success("Access removed.");
    },
    onError: (e) => toast.error(friendlyError(e, "Unable to remove this staff member.")),
  });

  if (isLoading) return <LoadingState label="Loading…" />;
  if (!isAdmin) {
    return (
      <>
        <PageHeader title="Staff" />
        <div className="panel">
          <EmptyState
            title="Administrators only"
            description="Only an administrator can manage who has access to the portal."
          />
        </div>
      </>
    );
  }

  function startEdit(member: StaffMember) {
    setEditingEmail(member.email);
    setForm({
      email: member.email,
      full_name: member.full_name,
      employee_id: member.employee_id,
      role: member.role,
    });
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const email = form.email.trim().toLowerCase();
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]{2,}$/.test(email)) {
      toast.error("Enter a valid email address.");
      return;
    }
    if (!form.full_name.trim()) {
      toast.error("Enter the staff member's full name. It appears on every record they create.");
      return;
    }
    save.mutate();
  }

  const rows = list.data ?? [];

  return (
    <>
      <PageHeader
        title="Staff"
        description="Only the emails listed here can use the portal. Their name and employee ID are recorded on everything they do."
      />

      <section className="panel mb-6 p-5">
        <h2 className="font-display text-base font-bold">How to give someone access</h2>
        <ol className="mt-3 list-decimal space-y-1 pl-5 text-sm text-muted-foreground">
          <li>Add their email below, with their name, employee ID and role.</li>
          <li>
            In your Supabase project open Authentication, then Users, and choose Add user. Enter the
            same email, tick &quot;Auto confirm user&quot; and set a long random password you do
            not share with anyone.
          </li>
          <li>
            Tell them to open the sign-in page and use &quot;Forgot your password, or setting it for
            the first time?&quot; to choose their own password.
          </li>
        </ol>
      </section>

      <form onSubmit={handleSubmit} className="panel mb-6 p-5">
        <h2 className="font-display text-base font-bold">
          {editingEmail ? "Edit staff member" : "Approve a staff member"}
        </h2>
        <div className="mt-4 grid gap-4 md:grid-cols-2">
          <div>
            <Label htmlFor="staff-email">Email *</Label>
            <Input
              id="staff-email"
              type="email"
              className="mt-2"
              value={form.email}
              disabled={editingEmail !== null}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              placeholder="name@college.edu"
            />
          </div>
          <div>
            <Label htmlFor="staff-name">Full name *</Label>
            <Input
              id="staff-name"
              className="mt-2"
              value={form.full_name}
              onChange={(e) => setForm({ ...form, full_name: e.target.value })}
            />
          </div>
          <div>
            <Label htmlFor="staff-id">Employee ID</Label>
            <Input
              id="staff-id"
              className="mt-2"
              value={form.employee_id}
              onChange={(e) => setForm({ ...form, employee_id: e.target.value })}
              placeholder="e.g. STF-014"
            />
          </div>
          <div>
            <Label>Role</Label>
            <Select
              value={form.role}
              onValueChange={(v) => setForm({ ...form, role: v as "admin" | "staff" })}
            >
              <SelectTrigger className="mt-2 w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="staff">Staff — registers students, verifies documents</SelectItem>
                <SelectItem value="admin">Administrator — also manages staff and settings</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <div className="mt-5 flex gap-2">
          <Button type="submit" disabled={save.isPending}>
            {save.isPending ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
            {editingEmail ? "Save changes" : "Approve"}
          </Button>
          {editingEmail && (
            <Button
              type="button"
              variant="ghost"
              onClick={() => {
                setEditingEmail(null);
                setForm(EMPTY);
              }}
            >
              Cancel
            </Button>
          )}
        </div>
      </form>

      <section className="panel overflow-hidden">
        <header className="border-b border-border px-5 py-4">
          <h2 className="font-display text-base font-bold">Approved staff</h2>
        </header>
        {list.isLoading ? (
          <LoadingState label="Loading staff…" />
        ) : list.isError ? (
          <ErrorState message={friendlyError(list.error, "Unable to load the staff list.")} />
        ) : rows.length === 0 ? (
          <EmptyState title="No staff yet" />
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Employee ID</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Added</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((m) => {
                  const isMe = m.email === profile?.email;
                  return (
                    <TableRow key={m.email}>
                      <TableCell className="font-medium">
                        {m.full_name || "—"}
                        {isMe && <span className="ml-2 text-xs text-muted-foreground">(you)</span>}
                      </TableCell>
                      <TableCell className="font-mono text-xs">{m.employee_id || "—"}</TableCell>
                      <TableCell className="text-muted-foreground">{m.email}</TableCell>
                      <TableCell className="capitalize">{m.role}</TableCell>
                      <TableCell className="text-muted-foreground">{formatDate(m.created_at)}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm" onClick={() => startEdit(m)}>
                          <Pencil className="size-4" />
                          Edit
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="sm" disabled={isMe}>
                              <Trash2 className="size-4" />
                              Remove
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Remove access for {m.full_name || m.email}?</AlertDialogTitle>
                              <AlertDialogDescription>
                                They will be locked out straight away. Records they created keep their
                                name. You can also delete their login under Authentication in Supabase.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Keep access</AlertDialogCancel>
                              <AlertDialogAction onClick={() => remove.mutate(m.email)}>
                                Remove access
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </section>
    </>
  );
}
