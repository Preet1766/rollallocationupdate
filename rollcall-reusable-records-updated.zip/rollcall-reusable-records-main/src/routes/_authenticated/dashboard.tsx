import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Users, UserCheck, UserX, Hash, PackageOpen, UserPlus } from "lucide-react";
import { fetchStudents, fetchAvailableRollNumbers } from "@/lib/api";
import { formatDate, formatRoll, friendlyError, staffLabel } from "@/lib/college";
import { useSettings } from "@/hooks/use-settings";
import {
  PageHeader,
  StatCard,
  StatusBadge,
  RollChip,
  LoadingState,
  EmptyState,
  ErrorState,
} from "@/components/portal-bits";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — College Admission Portal" },
      {
        name: "description",
        content:
          "Live overview of student admissions, active enrolments, cancellations and roll number usage.",
      },
      { property: "og:title", content: "Dashboard — College Admission Portal" },
      {
        property: "og:description",
        content: "Live overview of admissions and roll number allocation.",
      },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const { data: settings } = useSettings();
  const students = useQuery({ queryKey: ["students"], queryFn: fetchStudents });
  const available = useQuery({ queryKey: ["available-rolls"], queryFn: fetchAvailableRollNumbers });

  if (students.isLoading) return <LoadingState label="Loading dashboard…" />;
  if (students.isError) {
    return <ErrorState message={friendlyError(students.error, "Unable to load the dashboard.")} />;
  }

  const all = students.data ?? [];
  const active = all.filter((s) => s.status === "active");
  const cancelled = all.filter((s) => s.status === "cancelled");

  const recent = [...all]
    .sort((a, b) => (a.created_at < b.created_at ? 1 : -1))
    .slice(0, 6);
  const recentCancellations = [...cancelled]
    .sort((a, b) => ((a.cancelled_at ?? "") < (b.cancelled_at ?? "") ? 1 : -1))
    .slice(0, 5);

  return (
    <>
      <PageHeader
        title="Dashboard"
        description={settings?.college_name ?? "College administration overview"}
        actions={
          <Button asChild>
            <Link to="/register">
              <UserPlus className="size-4" />
              Register student
            </Link>
          </Button>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        <StatCard label="Total students" value={all.length} icon={Users} />
        <StatCard label="Active students" value={active.length} icon={UserCheck} tone="success" />
        <StatCard
          label="Cancelled admissions"
          value={cancelled.length}
          icon={UserX}
          tone="destructive"
        />
        <StatCard label="Assigned roll numbers" value={active.length} icon={Hash} tone="primary" />
        <StatCard
          label="Available roll numbers"
          value={available.data?.length ?? 0}
          icon={PackageOpen}
          tone="primary"
        />
      </div>

      <section className="panel mt-6 overflow-hidden">
        <header className="flex items-center justify-between border-b border-border px-5 py-4">
          <h2 className="font-display text-base font-bold">Recent registrations</h2>
          <Link to="/students" className="text-xs font-semibold text-primary hover:underline">
            View all
          </Link>
        </header>
        {recent.length === 0 ? (
          <EmptyState title="No students yet" description="Register your first student to begin." />
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Admission no.</TableHead>
                  <TableHead>Course</TableHead>
                  <TableHead>Roll no.</TableHead>
                  <TableHead>Registered</TableHead>
                  <TableHead>Registered by</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recent.map((s) => (
                  <TableRow key={s.id}>
                    <TableCell className="font-medium">
                      <Link
                        to="/students/$id"
                        params={{ id: s.id }}
                        className="hover:text-primary hover:underline"
                      >
                        {s.name}
                      </Link>
                    </TableCell>
                    <TableCell className="font-mono text-xs">{s.admission_number}</TableCell>
                    <TableCell>{s.course}</TableCell>
                    <TableCell>
                      <RollChip>{formatRoll(s.roll_number)}</RollChip>
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {formatDate(s.created_at)}
                    </TableCell>
                    <TableCell className="text-sm">
                      {staffLabel(s.registered_by_name, s.registered_by_staff_id)}
                    </TableCell>
                    <TableCell>
                      <StatusBadge status={s.status} />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </section>

      <section className="panel mt-6 overflow-hidden">
        <header className="border-b border-border px-5 py-4">
          <h2 className="font-display text-base font-bold">Recent cancellations</h2>
        </header>
        {recentCancellations.length === 0 ? (
          <EmptyState
            title="No cancellations"
            description="Cancelled admissions and their released roll numbers appear here."
          />
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student</TableHead>
                  <TableHead>Admission no.</TableHead>
                  <TableHead>Released roll no.</TableHead>
                  <TableHead>Cancelled on</TableHead>
                  <TableHead>Cancelled by</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recentCancellations.map((s) => (
                  <TableRow key={s.id}>
                    <TableCell className="font-medium">{s.name}</TableCell>
                    <TableCell className="font-mono text-xs">{s.admission_number}</TableCell>
                    <TableCell>
                      <RollChip>{formatRoll(s.roll_number)}</RollChip>
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {formatDate(s.cancelled_at)}
                    </TableCell>
                    <TableCell className="text-sm">
                      {staffLabel(s.cancelled_by_name, s.cancelled_by_staff_id)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </section>
    </>
  );
}
