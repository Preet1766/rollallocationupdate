import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, Search, UserPlus } from "lucide-react";
import { fetchDocumentSummaries, fetchStudents } from "@/lib/api";
import {
  REQUIRED_DOCUMENT_COUNT,
  formatDate,
  formatRoll,
  friendlyError,
  summariseDocuments,
} from "@/lib/college";
import { useCourses } from "@/hooks/use-courses";
import {
  PageHeader,
  StatusBadge,
  RollChip,
  LoadingState,
  EmptyState,
  ErrorState,
} from "@/components/portal-bits";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

type SearchParams = { q?: string | undefined };

export const Route = createFileRoute("/_authenticated/students/")({
  validateSearch: (search: Record<string, unknown>): SearchParams => ({
    q: typeof search["q"] === "string" && search["q"] ? String(search["q"]) : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Students — College Admission Portal" },
      {
        name: "description",
        content:
          "Search, filter and manage every registered student together with their assigned roll number.",
      },
      { property: "og:title", content: "Students — College Admission Portal" },
      { property: "og:description", content: "Manage registered students and roll numbers." },
    ],
  }),
  component: StudentsPage,
});

type SortKey = "roll" | "name" | "date";

const PAGE_SIZE = 25;

function StudentsPage() {
  const { q } = Route.useSearch();
  const navigate = useNavigate({ from: "/students/" });
  const { names: courseNames } = useCourses();
  const students = useQuery({ queryKey: ["students"], queryFn: fetchStudents });
  const docSummaries = useQuery({
    queryKey: ["document-summaries"],
    queryFn: fetchDocumentSummaries,
  });

  const [status, setStatus] = useState("all");
  const [course, setCourse] = useState("all");
  const [year, setYear] = useState("all");
  const [sort, setSort] = useState<SortKey>("roll");
  const [page, setPage] = useState(1);

  const docsByStudent = useMemo(() => {
    const map = new Map<string, Array<{ doc_type: string; status: string }>>();
    for (const d of docSummaries.data ?? []) {
      const list = map.get(d.student_id) ?? [];
      list.push(d);
      map.set(d.student_id, list);
    }
    return map;
  }, [docSummaries.data]);

  const years = useMemo(() => {
    const set = new Set<string>();
    for (const s of students.data ?? []) set.add(s.admission_date.slice(0, 4));
    return [...set].sort().reverse();
  }, [students.data]);

  const rows = useMemo(() => {
    const term = (q ?? "").trim().toLowerCase();
    let list = students.data ?? [];
    if (term) {
      list = list.filter(
        (s) =>
          s.name.toLowerCase().includes(term) ||
          s.admission_number.toLowerCase().includes(term) ||
          s.phone.toLowerCase().includes(term) ||
          String(s.roll_number ?? "").includes(term),
      );
    }
    if (status !== "all") list = list.filter((s) => s.status === status);
    if (course !== "all") list = list.filter((s) => s.course === course);
    if (year !== "all") list = list.filter((s) => s.admission_date.startsWith(year));
    return [...list].sort((a, b) => {
      if (sort === "name") return a.name.localeCompare(b.name);
      if (sort === "date") return a.created_at < b.created_at ? 1 : -1;
      return (a.roll_number ?? Number.MAX_SAFE_INTEGER) - (b.roll_number ?? Number.MAX_SAFE_INTEGER);
    });
  }, [students.data, q, status, course, year, sort]);

  const pageCount = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
  const currentPage = Math.min(page, pageCount);
  const visible = rows.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  return (
    <>
      <PageHeader
        title="Students"
        description="All registered students with their current roll numbers."
        actions={
          <Button asChild>
            <Link to="/register">
              <UserPlus className="size-4" />
              Register student
            </Link>
          </Button>
        }
      />

      <div className="panel mb-6 flex flex-wrap items-end gap-3 p-4">
        <div className="relative min-w-56 flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            className="pl-9"
            placeholder="Search by name, admission no, roll no or phone"
            value={q ?? ""}
            onChange={(e) => {
              setPage(1);
              navigate({ search: { q: e.target.value || undefined }, replace: true });
            }}
          />
        </div>
        <Filter
          label="Status"
          value={status}
          onChange={(v) => {
            setPage(1);
            setStatus(v);
          }}
          options={["active", "cancelled"]}
        />
        <Filter
          label="Course"
          value={course}
          onChange={(v) => {
            setPage(1);
            setCourse(v);
          }}
          options={courseNames}
        />
        <Filter
          label="Year"
          value={year}
          onChange={(v) => {
            setPage(1);
            setYear(v);
          }}
          options={years}
        />
        <div>
          <p className="label-caps mb-1">Sort by</p>
          <Select value={sort} onValueChange={(v) => setSort(v as SortKey)}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="roll">Roll number</SelectItem>
              <SelectItem value="name">Name</SelectItem>
              <SelectItem value="date">Newest first</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {students.isLoading ? (
        <LoadingState label="Loading students…" />
      ) : students.isError ? (
        <ErrorState message={friendlyError(students.error, "Unable to load students.")} />
      ) : rows.length === 0 ? (
        <EmptyState
          title="No students found"
          description="Try clearing the filters or register a new student."
        />
      ) : (
        <div className="panel overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Roll no.</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Admission no.</TableHead>
                <TableHead>Course</TableHead>
                <TableHead>Sem</TableHead>
                <TableHead>Registered</TableHead>
                <TableHead>Documents</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {visible.map((s) => {
                const docs = summariseDocuments(docsByStudent.get(s.id) ?? []);
                return (
                <TableRow key={s.id}>
                  <TableCell>
                    <RollChip>{formatRoll(s.roll_number)}</RollChip>
                  </TableCell>
                  <TableCell className="font-medium">{s.name}</TableCell>
                  <TableCell className="font-mono text-xs">{s.admission_number}</TableCell>
                  <TableCell>{s.course}</TableCell>
                  <TableCell>{s.semester}</TableCell>
                  <TableCell className="text-muted-foreground">{formatDate(s.created_at)}</TableCell>
                  <TableCell className="text-xs tabular-nums">
                    <span className={docs.complete ? "text-success" : "text-muted-foreground"}>
                      {docs.verified}/{REQUIRED_DOCUMENT_COUNT} verified
                    </span>
                    {docs.rejected > 0 && (
                      <span className="ml-1 text-destructive">· {docs.rejected} rejected</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <StatusBadge status={s.status} />
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm" asChild>
                      <Link to="/students/$id" params={{ id: s.id }}>
                        View
                      </Link>
                    </Button>
                  </TableCell>
                </TableRow>
                );
              })}
            </TableBody>
          </Table>
          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border px-4 py-3 text-sm">
            <span className="text-muted-foreground">
              Showing {(currentPage - 1) * PAGE_SIZE + 1}–
              {Math.min(currentPage * PAGE_SIZE, rows.length)} of {rows.length}
            </span>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                disabled={currentPage <= 1}
                onClick={() => setPage(currentPage - 1)}
              >
                <ChevronLeft className="size-4" />
                Previous
              </Button>
              <span className="tabular-nums text-muted-foreground">
                Page {currentPage} of {pageCount}
              </span>
              <Button
                variant="outline"
                size="sm"
                disabled={currentPage >= pageCount}
                onClick={() => setPage(currentPage + 1)}
              >
                Next
                <ChevronRight className="size-4" />
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

function Filter({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: string[];
}) {
  return (
    <div>
      <p className="label-caps mb-1">{label}</p>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger className="w-40">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All</SelectItem>
          {options.map((o) => (
            <SelectItem key={o} value={o} className="capitalize">
              {o}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
