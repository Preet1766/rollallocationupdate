import { createFileRoute, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/")({
  ssr: false,
  beforeLoad: async () => {
    const { data } = await supabase.auth.getSession();
    throw redirect({ to: data.session ? "/dashboard" : "/auth" });
  },
  head: () => ({
    meta: [
      { title: "College Admission & Roll Number Portal" },
      {
        name: "description",
        content:
          "Staff portal for college admissions with automatic, gap-filling roll number assignment.",
      },
      { property: "og:title", content: "College Admission & Roll Number Portal" },
      {
        property: "og:description",
        content: "Register students and assign roll numbers automatically.",
      },
    ],
  }),
  component: () => null,
});
