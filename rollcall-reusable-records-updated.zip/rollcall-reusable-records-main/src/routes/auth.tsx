import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { GraduationCap, Loader2, ShieldAlert } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { fetchMyStaffProfile } from "@/lib/api";

type AuthSearch = { denied?: string | undefined };

export const Route = createFileRoute("/auth")({
  validateSearch: (search: Record<string, unknown>): AuthSearch => ({
    denied: search["denied"] === "1" ? "1" : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Staff Sign In — College Admission Portal" },
      {
        name: "description",
        content:
          "Secure sign-in for college administrative staff to register students and manage roll numbers.",
      },
      { property: "og:title", content: "Staff Sign In — College Admission Portal" },
      {
        property: "og:description",
        content: "Secure staff access to the college admission and roll number system.",
      },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const { denied } = Route.useSearch();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [mode, setMode] = useState<"login" | "forgot">("login");

  useEffect(() => {
    void supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/dashboard", replace: true });
    });
  }, [navigate]);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      setLoading(false);
      toast.error("Sign in failed", { description: "Check your email and password." });
      return;
    }

    // Signing in is not enough: the account must be on the approved staff list.
    let approved = false;
    try {
      approved = (await fetchMyStaffProfile()) !== null;
    } catch {
      setLoading(false);
      await supabase.auth.signOut();
      toast.error("Unable to connect to the database. Please try again.");
      return;
    }
    setLoading(false);
    if (!approved) {
      await supabase.auth.signOut();
      toast.error("This account is not approved for staff access.", {
        description: "Please contact the portal administrator.",
      });
      return;
    }
    toast.success("Welcome back");
    navigate({ to: "/dashboard", replace: true });
  }

  async function handleForgot(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    await supabase.auth.resetPasswordForEmail(email.trim(), {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    setLoading(false);
    // Same message whether or not the address exists, so this cannot be used to probe accounts.
    toast.success("If that email has an account, a password reset link is on its way.");
    setMode("login");
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="relative hidden flex-col justify-between bg-sidebar p-12 lg:flex">
        <div className="flex items-center gap-3">
          <div className="flex size-11 items-center justify-center rounded-md bg-primary text-primary-foreground">
            <GraduationCap className="size-6" />
          </div>
          <span className="font-display text-lg font-bold">College Admission Portal</span>
        </div>
        <div>
          <div className="stripe-rule mb-8 w-32" />
          <h1 className="max-w-md font-display text-4xl font-bold leading-tight">
            Student registration &amp; automatic roll number allocation.
          </h1>
          <p className="mt-4 max-w-md text-sm text-muted-foreground">
            Register admissions, assign roll numbers automatically, cancel admissions and reuse
            freed roll numbers — all enforced inside the database.
          </p>
        </div>
        <p className="text-xs text-muted-foreground">Authorised staff access only.</p>
      </div>

      <div className="flex items-center justify-center p-6">
        <div className="w-full max-w-sm">
          <div className="mb-8 flex items-center gap-3 lg:hidden">
            <div className="flex size-10 items-center justify-center rounded-md bg-primary text-primary-foreground">
              <GraduationCap className="size-5" />
            </div>
            <span className="font-display font-bold">College Admission Portal</span>
          </div>

          <h2 className="font-display text-2xl font-bold">Staff sign in</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Accounts are created by the portal administrator. Use the credentials you were given.
          </p>

          {denied === "1" && (
            <div
              role="alert"
              className="mt-6 flex gap-3 rounded-lg border border-destructive/40 bg-destructive/10 p-4 text-sm"
            >
              <ShieldAlert className="mt-0.5 size-4 shrink-0 text-destructive" />
              <p>
                That account is not approved for staff access. Please contact the portal
                administrator.
              </p>
            </div>
          )}

          {mode === "login" ? (
            <form onSubmit={handleLogin} className="mt-6 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  required
                  autoComplete="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@college.edu"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  required
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
              <Button type="submit" className="w-full" disabled={loading}>
                {loading && <Loader2 className="size-4 animate-spin" />}
                Sign in
              </Button>
              <button
                type="button"
                className="w-full text-center text-xs text-muted-foreground underline underline-offset-4 hover:text-foreground"
                onClick={() => setMode("forgot")}
              >
                Forgot your password, or setting it for the first time?
              </button>
            </form>
          ) : (
            <form onSubmit={handleForgot} className="mt-6 space-y-4">
              <p className="text-sm text-muted-foreground">
                Enter your staff email. We will send you a link to choose a new password.
              </p>
              <div className="space-y-2">
                <Label htmlFor="reset-email">Email</Label>
                <Input
                  id="reset-email"
                  type="email"
                  required
                  autoComplete="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@college.edu"
                />
              </div>
              <Button type="submit" className="w-full" disabled={loading}>
                {loading && <Loader2 className="size-4 animate-spin" />}
                Send reset link
              </Button>
              <button
                type="button"
                className="w-full text-center text-xs text-muted-foreground underline underline-offset-4 hover:text-foreground"
                onClick={() => setMode("login")}
              >
                Back to sign in
              </button>
            </form>
          )}

          <p className="mt-6 text-center text-xs text-muted-foreground">
            <Link to="/" className="underline underline-offset-4 hover:text-foreground">
              Back to home
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
