import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useRef, useState } from "react";
import { FileUp, GraduationCap, Loader2, Lock } from "lucide-react";
import { toast } from "sonner";
import { fetchStudentPortal, studentUploadDocument } from "@/lib/api";
import {
  DOCUMENT_TYPES,
  formatDateTime,
  friendlyError,
  summariseDocuments,
  validateDocumentFile,
  type DocumentTypeKey,
} from "@/lib/college";
import { DocStatusBadge, ErrorState, LoadingState } from "@/components/portal-bits";
import { Button } from "@/components/ui/button";

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export const Route = createFileRoute("/upload/$token")({
  head: () => ({
    meta: [
      { title: "Upload Your Documents — College Admission Portal" },
      {
        name: "description",
        content: "Upload the documents needed to complete your college admission.",
      },
      { name: "robots", content: "noindex, nofollow" },
      { name: "referrer", content: "no-referrer" },
    ],
  }),
  component: UploadPage,
});

function UploadPage() {
  const { token } = Route.useParams();
  const queryClient = useQueryClient();
  const validToken = UUID_PATTERN.test(token);
  const inputRef = useRef<HTMLInputElement>(null);
  const pickedType = useRef<DocumentTypeKey | null>(null);
  const [busyType, setBusyType] = useState<string | null>(null);

  const portal = useQuery({
    queryKey: ["portal", token],
    queryFn: () => fetchStudentPortal(token),
    enabled: validToken,
    retry: false,
  });

  const upload = useMutation({
    mutationFn: (v: { type: DocumentTypeKey; file: File }) =>
      studentUploadDocument(token, v.type, v.file),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["portal", token] });
      toast.success("Uploaded. A staff member will check it soon.");
    },
    onError: (e) => toast.error(friendlyError(e, "Upload failed. Please try again.")),
    onSettled: () => setBusyType(null),
  });

  function chooseFile(type: DocumentTypeKey) {
    pickedType.current = type;
    inputRef.current?.click();
  }

  function onFileChosen(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    const type = pickedType.current;
    e.target.value = "";
    if (!file || !type) return;
    const problem = validateDocumentFile(file);
    if (problem) {
      toast.error(problem);
      return;
    }
    setBusyType(type);
    upload.mutate({ type, file });
  }

  const data = portal.data;
  const docs = data?.documents ?? [];
  const byType = new Map(docs.map((d) => [d.doc_type, d]));
  const summary = summariseDocuments(docs);

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-sidebar">
        <div className="mx-auto flex max-w-2xl items-center gap-3 px-5 py-4">
          <div className="flex size-9 items-center justify-center rounded-md bg-primary text-primary-foreground">
            <GraduationCap className="size-5" />
          </div>
          <div className="min-w-0">
            <p className="truncate font-display text-sm font-bold">
              {data?.college_name ?? "College Admission Portal"}
            </p>
            <p className="label-caps">Document upload</p>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-2xl px-5 py-8">
        {!validToken ? (
          <ErrorState message="This link is not valid. Please ask the college office for a new one." />
        ) : portal.isLoading ? (
          <LoadingState label="Opening your upload page…" />
        ) : portal.isError ? (
          <ErrorState message={friendlyError(portal.error, "Unable to open this page. Please try again.")} />
        ) : !data ? (
          <ErrorState message="This link is no longer valid. Please ask the college office for a new one." />
        ) : (
          <>
            <div className="stripe-rule mb-4 w-16" />
            <h1 className="font-display text-2xl font-bold md:text-3xl">Upload your documents</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              Upload a clear PDF, JPG or PNG of each document, up to 5 MB each. A staff member will
              check every file and mark it as verified, or tell you what to fix.
            </p>

            <section className="panel mt-6 p-5">
              <p className="label-caps">Student</p>
              <p className="mt-1 font-display text-lg font-bold">{data.name}</p>
              <p className="text-sm text-muted-foreground">
                Admission number <span className="font-mono">{data.admission_number}</span> ·{" "}
                {data.course}
              </p>
              <p className="mt-3 text-sm">
                {summary.complete
                  ? "All required documents are verified. Nothing more is needed."
                  : `${summary.verified} of ${summary.required} required documents verified.`}
              </p>
            </section>

            <input
              ref={inputRef}
              type="file"
              accept="application/pdf,image/jpeg,image/png"
              className="hidden"
              onChange={onFileChosen}
            />

            <ul className="panel mt-6 divide-y divide-border">
              {DOCUMENT_TYPES.map((type) => {
                const doc = byType.get(type.key);
                const status = doc ? doc.status : "missing";
                const locked = doc?.status === "verified";
                const busy = busyType === type.key;
                return (
                  <li key={type.key} className="flex flex-wrap items-center gap-3 p-4">
                    <div className="min-w-48 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-sm font-medium">{type.label}</span>
                        <DocStatusBadge status={status} />
                      </div>
                      {doc && (
                        <p className="mt-1 text-xs text-muted-foreground">
                          {doc.file_name} · {formatDateTime(doc.uploaded_at)}
                        </p>
                      )}
                      {doc?.status === "rejected" && doc.reject_reason && (
                        <p className="mt-1 text-xs text-destructive">
                          Please upload again. Reason: {doc.reject_reason}
                        </p>
                      )}
                    </div>
                    {locked ? (
                      <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
                        <Lock className="size-3.5" />
                        Verified
                      </span>
                    ) : (
                      <Button
                        type="button"
                        size="sm"
                        variant={doc ? "outline" : "secondary"}
                        disabled={busy || upload.isPending}
                        onClick={() => chooseFile(type.key)}
                      >
                        {busy ? (
                          <Loader2 className="size-4 animate-spin" />
                        ) : (
                          <FileUp className="size-4" />
                        )}
                        {doc ? "Upload again" : "Choose file"}
                      </Button>
                    )}
                  </li>
                );
              })}
            </ul>

            <p className="mt-6 text-xs text-muted-foreground">
              This page is private to you. Please do not share the link with anyone. Your documents
              are stored securely and are visible only to authorised college staff.
            </p>
          </>
        )}
      </main>
    </div>
  );
}
