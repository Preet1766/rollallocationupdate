import { useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Check, Copy, ExternalLink, Loader2, RefreshCw, Upload, X } from "lucide-react";
import { toast } from "sonner";
import {
  fetchDocuments,
  getDocumentUrl,
  regenerateUploadLink,
  staffUploadDocument,
  verifyDocument,
} from "@/lib/api";
import {
  DOCUMENT_TYPES,
  formatDateTime,
  friendlyError,
  staffLabel,
  summariseDocuments,
  uploadLink,
  validateDocumentFile,
  type DocumentTypeKey,
  type Student,
  type StudentDocument,
} from "@/lib/college";
import { DocStatusBadge, ErrorState, LoadingState } from "@/components/portal-bits";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

/** Staff view of a student's documents: share the upload link, open, verify or reject files. */
export function DocumentsPanel({ student }: { student: Student }) {
  const queryClient = useQueryClient();
  const docs = useQuery({
    queryKey: ["documents", student.id],
    queryFn: () => fetchDocuments(student.id),
  });
  const [rejecting, setRejecting] = useState<StudentDocument | null>(null);
  const [reason, setReason] = useState("");
  const [uploadingType, setUploadingType] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const pickedType = useRef<DocumentTypeKey | null>(null);

  const active = student.status === "active";
  const list = docs.data ?? [];
  const byType = new Map(list.map((d) => [d.doc_type, d]));
  const summary = summariseDocuments(list);
  const link = uploadLink(student.upload_token);

  function refresh() {
    void queryClient.invalidateQueries({ queryKey: ["documents"] });
    void queryClient.invalidateQueries({ queryKey: ["document-summaries"] });
  }

  const review = useMutation({
    mutationFn: (v: { id: string; approve: boolean; reason?: string }) =>
      verifyDocument(v.id, v.approve, v.reason),
    onSuccess: (doc) => {
      refresh();
      setRejecting(null);
      setReason("");
      toast.success(doc.status === "verified" ? "Document verified." : "Document rejected.");
    },
    onError: (e) => toast.error(friendlyError(e, "Unable to save the review. Please try again.")),
  });

  const newLink = useMutation({
    mutationFn: () => regenerateUploadLink(student.id),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["student", student.id] });
      void queryClient.invalidateQueries({ queryKey: ["students"] });
      toast.success("New upload link created. The old link no longer works.");
    },
    onError: (e) => toast.error(friendlyError(e, "Unable to create a new link.")),
  });

  async function copyLink() {
    try {
      await navigator.clipboard.writeText(link);
      toast.success("Upload link copied.");
    } catch {
      toast.error("Could not copy automatically. Select the link and copy it by hand.");
    }
  }

  async function openDocument(doc: StudentDocument) {
    const win = window.open("", "_blank");
    try {
      const url = await getDocumentUrl(doc.file_path);
      if (win) {
        win.opener = null;
        win.location.href = url;
      } else {
        window.location.href = url;
      }
    } catch (e) {
      win?.close();
      toast.error(friendlyError(e, "Unable to open this document."));
    }
  }

  function chooseFile(type: DocumentTypeKey) {
    pickedType.current = type;
    inputRef.current?.click();
  }

  async function onFileChosen(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    const type = pickedType.current;
    e.target.value = "";
    if (!file || !type) return;
    const problem = validateDocumentFile(file);
    if (problem) {
      toast.error(problem);
      return;
    }
    setUploadingType(type);
    try {
      await staffUploadDocument(student, type, file);
      refresh();
      toast.success("Document uploaded. It is awaiting review.");
    } catch (err) {
      toast.error(friendlyError(err, "Upload failed. Please try again."));
    } finally {
      setUploadingType(null);
    }
  }

  return (
    <section className="panel mt-6 p-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="font-display text-lg font-bold">Documents</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            {summary.verified} of {summary.required} required documents verified
            {summary.pending > 0 && ` · ${summary.pending} awaiting review`}
            {summary.rejected > 0 && ` · ${summary.rejected} rejected`}
          </p>
        </div>
        <div className="h-2 w-40 overflow-hidden rounded-full bg-muted" aria-hidden>
          <div
            className="h-full bg-primary"
            style={{ width: `${(summary.verified / summary.required) * 100}%` }}
          />
        </div>
      </div>

      {active && (
        <div className="mt-5 rounded-lg border border-border bg-surface-2 p-4">
          <p className="text-sm font-medium">Upload link for the student</p>
          <p className="mt-1 text-xs text-muted-foreground">
            Send this private link to the student. It only lets them upload their own documents and
            see their status. Do not post it publicly.
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            <Input readOnly value={link} className="min-w-64 flex-1 font-mono text-xs" />
            <Button type="button" variant="secondary" onClick={copyLink}>
              <Copy className="size-4" />
              Copy
            </Button>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button type="button" variant="outline" disabled={newLink.isPending}>
                  <RefreshCw className="size-4" />
                  New link
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Create a new upload link?</AlertDialogTitle>
                  <AlertDialogDescription>
                    The current link will stop working straight away. Use this if the link was
                    shared with the wrong person. Documents already uploaded are kept.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Keep current link</AlertDialogCancel>
                  <AlertDialogAction onClick={() => newLink.mutate()}>Create new link</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      )}

      <input
        ref={inputRef}
        type="file"
        accept="application/pdf,image/jpeg,image/png"
        className="hidden"
        onChange={onFileChosen}
      />

      {docs.isLoading ? (
        <LoadingState label="Loading documents…" />
      ) : docs.isError ? (
        <ErrorState message={friendlyError(docs.error, "Unable to load documents.")} />
      ) : (
        <ul className="mt-5 divide-y divide-border rounded-lg border border-border">
          {DOCUMENT_TYPES.map((type) => {
            const doc = byType.get(type.key);
            const status = doc ? (doc.status as "pending" | "verified" | "rejected") : "missing";
            const busy = uploadingType === type.key;
            return (
              <li key={type.key} className="flex flex-wrap items-center gap-3 p-4">
                <div className="min-w-56 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-sm font-medium">{type.label}</span>
                    <DocStatusBadge status={status} />
                  </div>
                  {doc && (
                    <div className="mt-1 space-y-0.5 text-xs text-muted-foreground">
                      <p>
                        {doc.file_name} · uploaded{" "}
                        {doc.uploaded_via === "student"
                          ? "by the student"
                          : `by staff (${doc.uploaded_by_name ?? "unknown"})`}{" "}
                        on {formatDateTime(doc.uploaded_at)}
                      </p>
                      {doc.reviewed_at && (
                        <p>
                          {doc.status === "verified" ? "Verified" : "Rejected"} by{" "}
                          {staffLabel(doc.reviewed_by_name, doc.reviewed_by_staff_id)} on{" "}
                          {formatDateTime(doc.reviewed_at)}
                        </p>
                      )}
                      {doc.status === "rejected" && doc.reject_reason && (
                        <p className="text-destructive">Reason: {doc.reject_reason}</p>
                      )}
                    </div>
                  )}
                </div>

                <div className="flex flex-wrap gap-2">
                  {doc && (
                    <Button type="button" size="sm" variant="ghost" onClick={() => openDocument(doc)}>
                      <ExternalLink className="size-4" />
                      View
                    </Button>
                  )}
                  {doc && doc.status !== "verified" && (
                    <Button
                      type="button"
                      size="sm"
                      variant="secondary"
                      disabled={review.isPending}
                      onClick={() => review.mutate({ id: doc.id, approve: true })}
                    >
                      <Check className="size-4" />
                      Verify
                    </Button>
                  )}
                  {doc && doc.status !== "rejected" && (
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setReason("");
                        setRejecting(doc);
                      }}
                    >
                      <X className="size-4" />
                      Reject
                    </Button>
                  )}
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    disabled={busy}
                    onClick={() => chooseFile(type.key)}
                  >
                    {busy ? <Loader2 className="size-4 animate-spin" /> : <Upload className="size-4" />}
                    {doc ? "Replace" : "Upload"}
                  </Button>
                </div>
              </li>
            );
          })}
        </ul>
      )}

      <Dialog
        open={rejecting !== null}
        onOpenChange={(open) => {
          if (!open) setRejecting(null);
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject document</DialogTitle>
            <DialogDescription>
              The student will see this reason on their upload page and can upload a new file.
            </DialogDescription>
          </DialogHeader>
          <Textarea
            rows={4}
            value={reason}
            placeholder="For example: the scan is blurred, please upload a clear copy."
            onChange={(e) => setReason(e.target.value)}
          />
          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => setRejecting(null)}>
              Cancel
            </Button>
            <Button
              type="button"
              variant="destructive"
              disabled={review.isPending || reason.trim() === ""}
              onClick={() => {
                if (rejecting) review.mutate({ id: rejecting.id, approve: false, reason: reason.trim() });
              }}
            >
              {review.isPending && <Loader2 className="size-4 animate-spin" />}
              Reject document
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </section>
  );
}
