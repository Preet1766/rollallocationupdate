import {
  formatDate,
  formatDateTime,
  formatRoll,
  staffLabel,
  type RollSettings,
  type Student,
} from "@/lib/college";

/** Print-only registration slip. Hidden on screen, rendered when the user prints. */
export function PrintableRecord({
  student,
  settings,
}: {
  student: Student;
  settings: RollSettings | null;
}) {
  const rows: Array<[string, string]> = [
    ["Admission number", student.admission_number],
    ["Full name", student.name],
    ["Guardian", student.guardian_name ?? "—"],
    ["Date of birth", formatDate(student.dob)],
    ["Gender", student.gender ?? "—"],
    ["Phone", student.phone ?? "—"],
    ["Email", student.email ?? "—"],
    ["Address", student.address ?? "—"],
    ["Course", student.course],
    ["Specialization", student.specialization ?? "—"],
    ["Semester", String(student.semester)],
    ["Academic year", student.academic_year ?? "—"],
    ["Admission date", formatDate(student.admission_date)],
    ["Status", student.status === "active" ? "Active" : "Cancelled"],
    ["Registered by", staffLabel(student.registered_by_name, student.registered_by_staff_id)],
    ["Registered on", formatDateTime(student.created_at)],
  ];

  return (
    <div className="print-area hidden">
      <header style={{ textAlign: "center", borderBottom: "2px solid #000", paddingBottom: 12 }}>
        <h1 style={{ fontSize: 22, fontWeight: 700, margin: 0 }}>
          {settings?.college_name ?? "College Admission Portal"}
        </h1>
        <p style={{ margin: "4px 0 0", fontSize: 12, letterSpacing: 2 }}>
          STUDENT REGISTRATION RECORD
        </p>
      </header>

      <div style={{ textAlign: "center", margin: "18px 0" }}>
        <p style={{ fontSize: 11, letterSpacing: 2, margin: 0 }}>ROLL NUMBER</p>
        <p style={{ fontSize: 30, fontWeight: 700, margin: "2px 0 0", letterSpacing: 3 }}>
          {formatRoll(student.roll_number)}
        </p>
      </div>

      <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
        <tbody>
          {rows.map(([label, value]) => (
            <tr key={label}>
              <th
                style={{
                  textAlign: "left",
                  padding: "6px 8px",
                  border: "1px solid #999",
                  width: "35%",
                  background: "#f2f2f2",
                }}
              >
                {label}
              </th>
              <td style={{ padding: "6px 8px", border: "1px solid #999" }}>{value}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div style={{ marginTop: 60, display: "flex", justifyContent: "space-between", fontSize: 12 }}>
        <span>
          _______________________
          <br />
          Student signature
        </span>
        <span>
          _______________________
          <br />
          {staffLabel(student.registered_by_name, student.registered_by_staff_id) === "—"
            ? "Registrar"
            : `Registrar: ${staffLabel(student.registered_by_name, student.registered_by_staff_id)}`}
        </span>
      </div>
    </div>
  );
}
