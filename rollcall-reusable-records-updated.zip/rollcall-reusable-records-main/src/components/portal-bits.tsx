import type { LucideIcon } from "lucide-react";
import { Inbox, Loader2, AlertTriangle } from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function PageHeader({
  title,
  description,
  actions,
}: {
  title: string;
  description?: string;
  actions?: ReactNode;
}) {
  return (
    <div className="mb-6">
      <div className="stripe-rule mb-4 w-16" />
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold md:text-3xl">{title}</h1>
          {description && <p className="mt-1 text-sm text-muted-foreground">{description}</p>}
        </div>
        {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
      </div>
    </div>
  );
}

export function StatCard({
  label,
  value,
  icon: Icon,
  tone = "default",
}: {
  label: string;
  value: ReactNode;
  icon: LucideIcon;
  tone?: "default" | "primary" | "success" | "destructive";
}) {
  const toneClass = {
    default: "text-foreground",
    primary: "text-primary",
    success: "text-success",
    destructive: "text-destructive",
  }[tone];

  return (
    <div className="panel p-5">
      <div className="flex items-start justify-between">
        <p className="label-caps">{label}</p>
        <Icon className={cn("size-4", toneClass)} />
      </div>
      <p className={cn("mt-3 font-display text-3xl font-bold tabular-nums", toneClass)}>{value}</p>
    </div>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const active = status === "active";
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-semibold",
        active
          ? "border-success/40 bg-success/10 text-success"
          : "border-destructive/40 bg-destructive/10 text-destructive",
      )}
    >
      <span className={cn("size-1.5 rounded-full", active ? "bg-success" : "bg-destructive")} />
      {active ? "Active" : "Cancelled"}
    </span>
  );
}

export function RollChip({ children }: { children: ReactNode }) {
  return (
    <span className="inline-flex rounded-md border border-primary/40 bg-accent px-2 py-0.5 font-mono text-xs font-bold text-accent-foreground">
      {children}
    </span>
  );
}

export function LoadingState({ label = "Loading…" }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-3 p-12 text-sm text-muted-foreground">
      <Loader2 className="size-4 animate-spin" />
      {label}
    </div>
  );
}

export function EmptyState({
  title,
  description,
  action,
}: {
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 p-12 text-center">
      <Inbox className="size-8 text-muted-foreground" />
      <p className="font-display font-semibold">{title}</p>
      {description && <p className="max-w-sm text-sm text-muted-foreground">{description}</p>}
      {action}
    </div>
  );
}

export function ErrorState({ message }: { message: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 p-12 text-center">
      <AlertTriangle className="size-8 text-destructive" />
      <p className="font-display font-semibold">Something went wrong</p>
      <p className="max-w-sm text-sm text-muted-foreground">{message}</p>
    </div>
  );
}

export type DocStatus = "missing" | "pending" | "verified" | "rejected";

export function DocStatusBadge({ status }: { status: DocStatus }) {
  const styles: Record<DocStatus, { cls: string; dot: string; label: string }> = {
    missing: {
      cls: "border-border bg-muted text-muted-foreground",
      dot: "bg-muted-foreground",
      label: "Not uploaded",
    },
    pending: {
      cls: "border-warning/40 bg-warning/10 text-warning",
      dot: "bg-warning",
      label: "Awaiting review",
    },
    verified: {
      cls: "border-success/40 bg-success/10 text-success",
      dot: "bg-success",
      label: "Verified",
    },
    rejected: {
      cls: "border-destructive/40 bg-destructive/10 text-destructive",
      dot: "bg-destructive",
      label: "Rejected",
    },
  };
  const s = styles[status];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-semibold",
        s.cls,
      )}
    >
      <span className={cn("size-1.5 rounded-full", s.dot)} />
      {s.label}
    </span>
  );
}
