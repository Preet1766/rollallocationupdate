import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  GraduationCap,
  LayoutDashboard,
  UserPlus,
  Users,
  Hash,
  Settings as SettingsIcon,
  ShieldCheck,
  LogOut,
  Search,
  Menu,
  X,
} from "lucide-react";
import { useState, type ReactNode } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { useSettings } from "@/hooks/use-settings";
import { useStaffProfile } from "@/hooks/use-staff";

const NAV = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard, adminOnly: false },
  { to: "/register", label: "Register Student", icon: UserPlus, adminOnly: false },
  { to: "/students", label: "Students", icon: Users, adminOnly: false },
  { to: "/roll-numbers", label: "Roll Numbers", icon: Hash, adminOnly: false },
  { to: "/staff", label: "Staff", icon: ShieldCheck, adminOnly: true },
  { to: "/settings", label: "Settings", icon: SettingsIcon, adminOnly: true },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const { data: settings } = useSettings();
  const { profile, isAdmin } = useStaffProfile();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [term, setTerm] = useState("");
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  async function handleSignOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  function submitSearch(e: React.FormEvent) {
    e.preventDefault();
    navigate({ to: "/students", search: { q: term } });
  }

  const collegeName = settings?.college_name ?? "College Portal";

  return (
    <div className="min-h-screen bg-background">
      {/* Sidebar */}
      <aside
        className={cn(
          "no-print fixed inset-y-0 left-0 z-50 w-64 border-r border-sidebar-border bg-sidebar transition-transform lg:translate-x-0",
          open ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="flex h-16 items-center gap-3 border-b border-sidebar-border px-5">
          <div className="flex size-9 items-center justify-center rounded-md bg-primary text-primary-foreground">
            <GraduationCap className="size-5" />
          </div>
          <div className="min-w-0">
            <p className="truncate font-display text-sm font-bold text-sidebar-foreground">
              {collegeName}
            </p>
            <p className="label-caps">Admin Portal</p>
          </div>
          <button
            className="ml-auto text-sidebar-foreground lg:hidden"
            onClick={() => setOpen(false)}
            aria-label="Close navigation"
          >
            <X className="size-5" />
          </button>
        </div>

        <nav className="space-y-1 p-3">
          {NAV.filter((item) => !item.adminOnly || isAdmin).map(({ to, label, icon: Icon }) => {
            const active = pathname === to || pathname.startsWith(to + "/");
            return (
              <Link
                key={to}
                to={to}
                onClick={() => setOpen(false)}
                className={cn(
                  "flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium transition-colors",
                  active
                    ? "bg-sidebar-primary text-sidebar-primary-foreground"
                    : "text-sidebar-foreground/75 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
                )}
              >
                <Icon className="size-4 shrink-0" />
                {label}
              </Link>
            );
          })}
        </nav>

        <div className="absolute inset-x-0 bottom-0 border-t border-sidebar-border p-3">
          <div className="px-3 pb-2">
            <p className="truncate text-sm font-medium text-sidebar-foreground">
              {profile?.full_name ?? "Staff"}
            </p>
            <p className="truncate text-xs text-muted-foreground">
              {profile?.employee_id ? `ID ${profile.employee_id} · ` : ""}
              {profile?.email ?? ""}
            </p>
          </div>
          <Button variant="ghost" className="w-full justify-start gap-3" onClick={handleSignOut}>
            <LogOut className="size-4" />
            Sign out
          </Button>
        </div>
      </aside>

      {open && (
        <div
          className="no-print fixed inset-0 z-40 bg-black/60 lg:hidden"
          onClick={() => setOpen(false)}
        />
      )}

      <div className="lg:pl-64">
        <header className="no-print sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-border bg-background/95 px-4 backdrop-blur md:px-6">
          <button
            className="text-foreground lg:hidden"
            onClick={() => setOpen(true)}
            aria-label="Open navigation"
          >
            <Menu className="size-5" />
          </button>
          <form onSubmit={submitSearch} className="relative w-full max-w-md">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={term}
              onChange={(e) => setTerm(e.target.value)}
              placeholder="Search admission no, name, roll no or phone…"
              className="pl-9"
              aria-label="Global search"
            />
          </form>
          <div className="ml-auto hidden items-center gap-2 sm:flex">
            <span className="rounded-full border border-primary/40 bg-accent px-3 py-1 text-xs font-semibold text-accent-foreground">
              {isAdmin ? "Administrator" : "Staff"}
            </span>
          </div>
        </header>

        <main className="p-4 md:p-6">{children}</main>
      </div>
    </div>
  );
}
