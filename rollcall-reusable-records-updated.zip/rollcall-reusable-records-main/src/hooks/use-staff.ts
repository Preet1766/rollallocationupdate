import { useQuery } from "@tanstack/react-query";
import { fetchMyStaffProfile } from "@/lib/api";

/** The signed-in staff member (name, employee id, role). Null until loaded. */
export function useStaffProfile() {
  const query = useQuery({
    queryKey: ["staff-profile"],
    queryFn: fetchMyStaffProfile,
    staleTime: 5 * 60_000,
  });
  return {
    ...query,
    profile: query.data ?? null,
    isAdmin: query.data?.role === "admin",
  };
}
