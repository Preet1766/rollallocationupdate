import { useQuery } from "@tanstack/react-query";
import { fetchCourses } from "@/lib/api";
import { DEFAULT_COURSES } from "@/lib/college";

/** Courses offered, read from the database (falls back to the built-in list while loading). */
export function useCourses() {
  const query = useQuery({
    queryKey: ["courses"],
    queryFn: fetchCourses,
    staleTime: 10 * 60_000,
  });
  const courses =
    query.data && query.data.length > 0
      ? query.data.map((c) => ({ name: c.name, code: c.code }))
      : [...DEFAULT_COURSES];
  return { courses, names: courses.map((c) => c.name), isLoading: query.isLoading };
}
