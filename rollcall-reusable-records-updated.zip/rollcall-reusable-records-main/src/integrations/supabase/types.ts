export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      courses: {
        Row: {
          active: boolean
          code: number
          name: string
          sort_order: number
        }
        Insert: {
          active?: boolean
          code: number
          name: string
          sort_order?: number
        }
        Update: {
          active?: boolean
          code?: number
          name?: string
          sort_order?: number
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          email: string
          id: string
          name: string
        }
        Insert: {
          created_at?: string
          email?: string
          id: string
          name?: string
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          name?: string
        }
        Relationships: []
      }
      roll_number_assignments: {
        Row: {
          assigned_at: string
          assigned_by: string | null
          assigned_by_name: string | null
          assigned_by_staff_id: string | null
          id: string
          released_at: string | null
          released_by: string | null
          released_by_name: string | null
          released_by_staff_id: string | null
          roll_number: number
          status: string
          student_id: string
        }
        Insert: {
          assigned_at?: string
          assigned_by?: string | null
          assigned_by_name?: string | null
          assigned_by_staff_id?: string | null
          id?: string
          released_at?: string | null
          released_by?: string | null
          released_by_name?: string | null
          released_by_staff_id?: string | null
          roll_number: number
          status?: string
          student_id: string
        }
        Update: {
          assigned_at?: string
          assigned_by?: string | null
          assigned_by_name?: string | null
          assigned_by_staff_id?: string | null
          id?: string
          released_at?: string | null
          released_by?: string | null
          released_by_name?: string | null
          released_by_staff_id?: string | null
          roll_number?: number
          status?: string
          student_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "roll_number_assignments_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      roll_settings: {
        Row: {
          college_name: string
          id: number
          updated_at: string
        }
        Insert: {
          college_name?: string
          id?: number
          updated_at?: string
        }
        Update: {
          college_name?: string
          id?: number
          updated_at?: string
        }
        Relationships: []
      }
      staff_allowlist: {
        Row: {
          created_at: string
          email: string
          employee_id: string
          full_name: string
          role: Database["public"]["Enums"]["app_role"]
        }
        Insert: {
          created_at?: string
          email: string
          employee_id?: string
          full_name?: string
          role?: Database["public"]["Enums"]["app_role"]
        }
        Update: {
          created_at?: string
          email?: string
          employee_id?: string
          full_name?: string
          role?: Database["public"]["Enums"]["app_role"]
        }
        Relationships: []
      }
      student_documents: {
        Row: {
          doc_type: string
          file_name: string
          file_path: string
          id: string
          mime_type: string
          reject_reason: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          reviewed_by_name: string | null
          reviewed_by_staff_id: string | null
          size_bytes: number
          status: string
          student_id: string
          uploaded_at: string
          uploaded_by: string | null
          uploaded_by_name: string | null
          uploaded_via: string
        }
        Insert: {
          doc_type: string
          file_name: string
          file_path: string
          id?: string
          mime_type: string
          reject_reason?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          reviewed_by_name?: string | null
          reviewed_by_staff_id?: string | null
          size_bytes: number
          status?: string
          student_id: string
          uploaded_at?: string
          uploaded_by?: string | null
          uploaded_by_name?: string | null
          uploaded_via: string
        }
        Update: {
          doc_type?: string
          file_name?: string
          file_path?: string
          id?: string
          mime_type?: string
          reject_reason?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          reviewed_by_name?: string | null
          reviewed_by_staff_id?: string | null
          size_bytes?: number
          status?: string
          student_id?: string
          uploaded_at?: string
          uploaded_by?: string | null
          uploaded_by_name?: string | null
          uploaded_via?: string
        }
        Relationships: [
          {
            foreignKeyName: "student_documents_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      students: {
        Row: {
          academic_year: string
          address: string
          admission_date: string
          admission_number: string
          cancelled_at: string | null
          cancelled_by: string | null
          cancelled_by_name: string | null
          cancelled_by_staff_id: string | null
          course: string
          created_at: string
          created_by: string | null
          dob: string | null
          email: string
          gender: string
          guardian_name: string
          id: string
          name: string
          phone: string
          registered_by_name: string | null
          registered_by_staff_id: string | null
          roll_number: number | null
          semester: number
          specialization: string
          status: string
          updated_at: string
          upload_token: string
        }
        Insert: {
          academic_year?: string
          address?: string
          admission_date?: string
          admission_number: string
          cancelled_at?: string | null
          cancelled_by?: string | null
          cancelled_by_name?: string | null
          cancelled_by_staff_id?: string | null
          course: string
          created_at?: string
          created_by?: string | null
          dob?: string | null
          email?: string
          gender?: string
          guardian_name?: string
          id?: string
          name: string
          phone?: string
          registered_by_name?: string | null
          registered_by_staff_id?: string | null
          roll_number?: number | null
          semester?: number
          specialization?: string
          status?: string
          updated_at?: string
          upload_token?: string
        }
        Update: {
          academic_year?: string
          address?: string
          admission_date?: string
          admission_number?: string
          cancelled_at?: string | null
          cancelled_by?: string | null
          cancelled_by_name?: string | null
          cancelled_by_staff_id?: string | null
          course?: string
          created_at?: string
          created_by?: string | null
          dob?: string | null
          email?: string
          gender?: string
          guardian_name?: string
          id?: string
          name?: string
          phone?: string
          registered_by_name?: string | null
          registered_by_staff_id?: string | null
          roll_number?: number | null
          semester?: number
          specialization?: string
          status?: string
          updated_at?: string
          upload_token?: string
        }
        Relationships: [
          {
            foreignKeyName: "students_course_fkey"
            columns: ["course"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["name"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      available_roll_numbers: {
        Args: never
        Returns: {
          roll_number: number
        }[]
      }
      cancel_admission: {
        Args: { _student_id: string }
        Returns: {
          academic_year: string
          address: string
          admission_date: string
          admission_number: string
          cancelled_at: string | null
          cancelled_by: string | null
          cancelled_by_name: string | null
          cancelled_by_staff_id: string | null
          course: string
          created_at: string
          created_by: string | null
          dob: string | null
          email: string
          gender: string
          guardian_name: string
          id: string
          name: string
          phone: string
          registered_by_name: string | null
          registered_by_staff_id: string | null
          roll_number: number | null
          semester: number
          specialization: string
          status: string
          updated_at: string
          upload_token: string
        }
        SetofOptions: {
          from: "*"
          to: "students"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_staff: { Args: { _user_id: string }; Returns: boolean }
      my_staff_profile: {
        Args: never
        Returns: {
          email: string
          employee_id: string
          full_name: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }[]
      }
      next_available_roll_number: {
        Args: { _admission_date: string; _course: string }
        Returns: number
      }
      regenerate_upload_link: { Args: { _student_id: string }; Returns: string }
      register_student: {
        Args: { payload: Json }
        Returns: {
          academic_year: string
          address: string
          admission_date: string
          admission_number: string
          cancelled_at: string | null
          cancelled_by: string | null
          cancelled_by_name: string | null
          cancelled_by_staff_id: string | null
          course: string
          created_at: string
          created_by: string | null
          dob: string | null
          email: string
          gender: string
          guardian_name: string
          id: string
          name: string
          phone: string
          registered_by_name: string | null
          registered_by_staff_id: string | null
          roll_number: number | null
          semester: number
          specialization: string
          status: string
          updated_at: string
          upload_token: string
        }
        SetofOptions: {
          from: "*"
          to: "students"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      staff_register_document: {
        Args: {
          _doc_type: string
          _file_name: string
          _mime: string
          _path: string
          _size: number
          _student_id: string
        }
        Returns: undefined
      }
      student_portal_get: { Args: { _token: string }; Returns: Json }
      student_portal_register_document: {
        Args: {
          _doc_type: string
          _file_name: string
          _mime: string
          _path: string
          _size: number
          _token: string
        }
        Returns: undefined
      }
      update_student: {
        Args: { _student_id: string; payload: Json }
        Returns: {
          academic_year: string
          address: string
          admission_date: string
          admission_number: string
          cancelled_at: string | null
          cancelled_by: string | null
          cancelled_by_name: string | null
          cancelled_by_staff_id: string | null
          course: string
          created_at: string
          created_by: string | null
          dob: string | null
          email: string
          gender: string
          guardian_name: string
          id: string
          name: string
          phone: string
          registered_by_name: string | null
          registered_by_staff_id: string | null
          roll_number: number | null
          semester: number
          specialization: string
          status: string
          updated_at: string
          upload_token: string
        }
        SetofOptions: {
          from: "*"
          to: "students"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      verify_document: {
        Args: { _approve: boolean; _doc_id: string; _reason?: string }
        Returns: {
          doc_type: string
          file_name: string
          file_path: string
          id: string
          mime_type: string
          reject_reason: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          reviewed_by_name: string | null
          reviewed_by_staff_id: string | null
          size_bytes: number
          status: string
          student_id: string
          uploaded_at: string
          uploaded_by: string | null
          uploaded_by_name: string | null
          uploaded_via: string
        }
        SetofOptions: {
          from: "*"
          to: "student_documents"
          isOneToOne: true
          isSetofReturn: false
        }
      }
    }
    Enums: {
      app_role: "admin" | "staff"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "staff"],
    },
  },
} as const
