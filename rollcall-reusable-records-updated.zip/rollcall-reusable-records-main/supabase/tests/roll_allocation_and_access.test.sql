-- =====================================================================
-- DATABASE TESTS: roll number allocation, cancellation/reuse, access control
--
-- HOW TO RUN
--   Paste the whole file into the Supabase SQL editor and run it.
--   * If it finishes with  "ALL DATABASE TESTS PASSED"  everything works.
--   * If something is wrong it stops with  "TEST FAILED: ..."  and says what.
--   The script ends with ROLLBACK, so it leaves NO data behind.
--
-- It uses admission years 2098 and 2099 (far future) so it never touches
-- real student records. It refuses to run if such records already exist.
--
-- What is checked
--   1  new registration            6  lowest free number chosen
--   2  duplicate admission number  7  groups (year / course) are independent
--   3  automatic assignment        8  duplicate active roll number blocked
--   4  sequential assignment       9  unapproved account is refused
--   5  cancel + reuse              10 staff cannot edit rolls/status directly
--   plus: who registered / cancelled is recorded, field validation, locks
-- =====================================================================
BEGIN;

-- ---- test fixtures --------------------------------------------------
INSERT INTO auth.users (id, email, email_confirmed_at, aud, role, raw_app_meta_data, raw_user_meta_data)
VALUES
  ('00000000-0000-0000-0000-0000000000a1', 'test-admin@example.test', now(), 'authenticated', 'authenticated', '{}', '{}'),
  ('00000000-0000-0000-0000-0000000000b2', 'test-stranger@example.test', now(), 'authenticated', 'authenticated', '{}', '{}');

INSERT INTO public.staff_allowlist (email, role, full_name, employee_id)
VALUES ('test-admin@example.test', 'admin', 'Test Admin', 'STF-001');
-- test-stranger is deliberately NOT on the approved list.

CREATE FUNCTION public._t_expect_error(_sql text, _expected text) RETURNS void
LANGUAGE plpgsql AS $$
BEGIN
  EXECUTE _sql;
  RAISE EXCEPTION 'TEST FAILED: expected an error containing "%", but it succeeded: %', _expected, _sql;
EXCEPTION WHEN OTHERS THEN
  IF SQLERRM LIKE 'TEST FAILED%' THEN RAISE; END IF;
  IF position(_expected IN SQLERRM) = 0 THEN
    RAISE EXCEPTION 'TEST FAILED: expected an error containing "%", got "%" (sql: %)', _expected, SQLERRM, _sql;
  END IF;
END $$;
GRANT EXECUTE ON FUNCTION public._t_expect_error(text, text) TO authenticated, anon;

DO $$
BEGIN
  ASSERT NOT EXISTS (SELECT 1 FROM public.students WHERE roll_number BETWEEN 13980000 AND 13999999),
    'TEST FAILED: records already exist in admission years 2098/2099; refusing to run';
END $$;

-- ---- act as the approved administrator ------------------------------
SELECT set_config('request.jwt.claims',
  '{"sub":"00000000-0000-0000-0000-0000000000a1","role":"authenticated"}', true);
SELECT set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-0000000000a1', true);
SET LOCAL ROLE authenticated;

-- 1/3/4. New registrations get automatic, sequential roll numbers (MCA = digit 7, year 2099)
DO $$
DECLARE r public.students;
BEGIN
  r := public.register_student('{"admission_number":"T-001","name":"Test One","course":"MCA","admission_date":"2099-07-01","semester":1}');
  ASSERT r.roll_number = 13997001, 'TEST FAILED: first MCA 2099 student should get 13997001, got ' || r.roll_number;
  ASSERT r.status = 'active', 'TEST FAILED: new student should be active';

  r := public.register_student('{"admission_number":"T-002","name":"Test Two","course":"MCA","admission_date":"2099-07-01","semester":1}');
  ASSERT r.roll_number = 13997002, 'TEST FAILED: second should get 13997002, got ' || r.roll_number;
  r := public.register_student('{"admission_number":"T-003","name":"Test Three","course":"MCA","admission_date":"2099-07-01","semester":1}');
  ASSERT r.roll_number = 13997003, 'TEST FAILED: third should get 13997003, got ' || r.roll_number;
  r := public.register_student('{"admission_number":"T-004","name":"Test Four","course":"MCA","admission_date":"2099-07-01","semester":1}');
  ASSERT r.roll_number = 13997004, 'TEST FAILED: fourth should get 13997004, got ' || r.roll_number;
END $$;

-- who registered is recorded (name + employee id + account UID)
DO $$
DECLARE s public.students; a public.roll_number_assignments;
BEGIN
  SELECT * INTO s FROM public.students WHERE admission_number = 'T-001';
  ASSERT s.registered_by_name = 'Test Admin' AND s.registered_by_staff_id = 'STF-001',
    'TEST FAILED: registered_by name / staff id not recorded';
  ASSERT s.created_by = '00000000-0000-0000-0000-0000000000a1'::uuid, 'TEST FAILED: created_by UID not recorded';
  SELECT * INTO a FROM public.roll_number_assignments WHERE student_id = s.id;
  ASSERT a.assigned_by_name = 'Test Admin' AND a.assigned_by_staff_id = 'STF-001' AND a.status = 'assigned',
    'TEST FAILED: assignment history missing the staff name / id';
END $$;

-- 2. Duplicate admission number (also ignoring upper/lower case)
SELECT public._t_expect_error(
  $q$SELECT public.register_student('{"admission_number":"T-002","name":"Dup","course":"MCA","admission_date":"2099-07-01","semester":1}')$q$,
  'DUPLICATE_ADMISSION');
SELECT public._t_expect_error(
  $q$SELECT public.register_student('{"admission_number":"t-002","name":"Dup","course":"MCA","admission_date":"2099-07-01","semester":1}')$q$,
  'DUPLICATE_ADMISSION');

-- 5. Cancelling frees the number and records who did it
DO $$
DECLARE s public.students; a public.roll_number_assignments;
BEGIN
  SELECT * INTO s FROM public.students WHERE admission_number = 'T-002';
  s := public.cancel_admission(s.id);
  ASSERT s.status = 'cancelled' AND s.cancelled_at IS NOT NULL, 'TEST FAILED: student should be cancelled';
  ASSERT s.roll_number = 13997002, 'TEST FAILED: the cancelled student keeps the number as history';
  ASSERT s.cancelled_by_name = 'Test Admin' AND s.cancelled_by_staff_id = 'STF-001',
    'TEST FAILED: cancelled_by name / staff id not recorded';
  SELECT * INTO a FROM public.roll_number_assignments WHERE student_id = s.id;
  ASSERT a.status = 'released' AND a.released_at IS NOT NULL AND a.released_by_name = 'Test Admin',
    'TEST FAILED: assignment should be released with the staff name';
  ASSERT EXISTS (SELECT 1 FROM public.available_roll_numbers() WHERE roll_number = 13997002),
    'TEST FAILED: 13997002 should appear in the available pool';
END $$;

SELECT public._t_expect_error(
  $q$SELECT public.cancel_admission((SELECT id FROM public.students WHERE admission_number = 'T-002'))$q$,
  'ALREADY_CANCELLED');

-- 5/6. The next student gets the freed number, NOT 13997005
DO $$
DECLARE r public.students;
BEGIN
  r := public.register_student('{"admission_number":"T-005","name":"Test Five","course":"MCA","admission_date":"2099-07-01","semester":1}');
  ASSERT r.roll_number = 13997002, 'TEST FAILED: should reuse 13997002, got ' || r.roll_number;
END $$;

-- 6. Lowest free number is chosen when several are free
DO $$
DECLARE r public.students;
BEGIN
  PERFORM public.cancel_admission((SELECT id FROM public.students WHERE admission_number = 'T-003'));  -- frees ...003
  PERFORM public.cancel_admission((SELECT id FROM public.students WHERE admission_number = 'T-001'));  -- frees ...001
  ASSERT (SELECT public.next_available_roll_number('MCA', '2099-07-01')) = 13997001,
    'TEST FAILED: preview should show the lowest free number 13997001';
  r := public.register_student('{"admission_number":"T-006","name":"Test Six","course":"MCA","admission_date":"2099-07-01","semester":1}');
  ASSERT r.roll_number = 13997001, 'TEST FAILED: lowest free is 13997001, got ' || r.roll_number;
  r := public.register_student('{"admission_number":"T-007","name":"Test Seven","course":"MCA","admission_date":"2099-07-01","semester":1}');
  ASSERT r.roll_number = 13997003, 'TEST FAILED: next lowest free is 13997003, got ' || r.roll_number;
  r := public.register_student('{"admission_number":"T-008","name":"Test Eight","course":"MCA","admission_date":"2099-07-01","semester":1}');
  ASSERT r.roll_number = 13997005, 'TEST FAILED: with nothing free the next serial is 13997005, got ' || r.roll_number;
END $$;

-- 7. Different course and different year have their own counters
DO $$
DECLARE r public.students;
BEGIN
  r := public.register_student('{"admission_number":"T-101","name":"BCA Student","course":"BCA","admission_date":"2099-07-01","semester":1}');
  ASSERT r.roll_number = 13990001, 'TEST FAILED: first BCA 2099 should be 13990001, got ' || r.roll_number;
  r := public.register_student('{"admission_number":"T-102","name":"BSc Student","course":"BSc","admission_date":"2099-07-01","semester":1}');
  ASSERT r.roll_number = 13991001, 'TEST FAILED: first BSc 2099 should be 13991001, got ' || r.roll_number;
  r := public.register_student('{"admission_number":"T-103","name":"Old Year","course":"MCA","admission_date":"2098-07-01","semester":1}');
  ASSERT r.roll_number = 13987001, 'TEST FAILED: first MCA 2098 should be 13987001, got ' || r.roll_number;
END $$;

-- Validation happens in the database too
SELECT public._t_expect_error(
  $q$SELECT public.register_student('{"admission_number":"T-201","name":"X","course":"MCA","admission_date":"2099-07-01","semester":1,"phone":"abc"}')$q$,
  'INVALID_PHONE');
SELECT public._t_expect_error(
  $q$SELECT public.register_student('{"admission_number":"T-202","name":"X","course":"MCA","admission_date":"2099-07-01","semester":1,"email":"nope"}')$q$,
  'INVALID_EMAIL');
SELECT public._t_expect_error(
  $q$SELECT public.register_student('{"admission_number":"T-203","name":"X","course":"MCA","admission_date":"2099-07-01","semester":9}')$q$,
  'INVALID_SEMESTER');
SELECT public._t_expect_error(
  $q$SELECT public.register_student('{"admission_number":"T-204","name":"X","course":"MCA","admission_date":"2099-07-01","semester":1,"specialization":"Web Development"}')$q$,
  'INVALID_SPECIALIZATION');
SELECT public._t_expect_error(
  $q$SELECT public.register_student('{"admission_number":"T-205","name":"X","course":"BBA","admission_date":"2099-07-01","semester":1}')$q$,
  'INVALID_COURSE');

-- The three specializations are accepted
DO $$
DECLARE r public.students;
BEGIN
  r := public.register_student('{"admission_number":"T-301","name":"AI Student","course":"BCA","admission_date":"2099-07-01","semester":1,"specialization":"Artificial Intelligence & Machine Learning"}');
  ASSERT r.specialization = 'Artificial Intelligence & Machine Learning', 'TEST FAILED: AI & ML specialization';
  r := public.register_student('{"admission_number":"T-302","name":"DS Student","course":"BCA","admission_date":"2099-07-01","semester":1,"specialization":"Data Science"}');
  ASSERT r.specialization = 'Data Science', 'TEST FAILED: Data Science specialization';
  r := public.register_student('{"admission_number":"T-303","name":"Reg Student","course":"BCA","admission_date":"2099-07-01","semester":1}');
  ASSERT r.specialization = 'Regular', 'TEST FAILED: default specialization should be Regular';
END $$;

-- 10. Staff cannot edit roll numbers / status directly, nor insert rows directly
SELECT public._t_expect_error(
  $q$UPDATE public.students SET roll_number = 13997999 WHERE admission_number = 'T-005'$q$, 'permission denied');
SELECT public._t_expect_error(
  $q$UPDATE public.students SET status = 'active' WHERE admission_number = 'T-001'$q$, 'permission denied');
SELECT public._t_expect_error(
  $q$INSERT INTO public.students (admission_number, name, course) VALUES ('T-999', 'Sneaky', 'MCA')$q$, 'permission denied');
SELECT public._t_expect_error(
  $q$UPDATE public.roll_number_assignments SET roll_number = 13997999$q$, 'permission denied');

-- ...and the safe edit function locks the fields that decide the roll number
SELECT public._t_expect_error(
  $q$SELECT public.update_student((SELECT id FROM public.students WHERE admission_number = 'T-005'), '{"course":"BCA"}')$q$,
  'LOCKED_FIELD');
SELECT public._t_expect_error(
  $q$SELECT public.update_student((SELECT id FROM public.students WHERE admission_number = 'T-005'), '{"admission_date":"2098-01-01"}')$q$,
  'LOCKED_FIELD');
SELECT public._t_expect_error(
  $q$SELECT public.update_student((SELECT id FROM public.students WHERE admission_number = 'T-005'), '{"roll_number":13997999}')$q$,
  'LOCKED_FIELD');
SELECT public._t_expect_error(
  $q$SELECT public.update_student((SELECT id FROM public.students WHERE admission_number = 'T-001'), '{"name":"Edited"}')$q$,
  'CANCELLED_READONLY');
DO $$
DECLARE r public.students;
BEGIN
  r := public.update_student((SELECT id FROM public.students WHERE admission_number = 'T-005'),
                             '{"name":"Test Five Edited","phone":"9876543210","semester":2}');
  ASSERT r.name = 'Test Five Edited' AND r.semester = 2 AND r.roll_number = 13997002,
    'TEST FAILED: allowed edit should work and leave the roll number untouched';
END $$;

-- ---- 8. The database itself blocks a second ACTIVE holder of a roll number
RESET ROLE;
SELECT public._t_expect_error(
  $q$INSERT INTO public.students (admission_number, name, course, roll_number, status)
     VALUES ('T-998', 'Clash', 'MCA', 13997002, 'active')$q$, 'duplicate key');
-- (a cancelled record may keep an old number, so this is allowed:)
INSERT INTO public.students (admission_number, name, course, roll_number, status)
VALUES ('T-997', 'History only', 'MCA', 13997002, 'cancelled');

-- ---- 9. An account that is not on the approved list gets nothing -----
SELECT set_config('request.jwt.claims',
  '{"sub":"00000000-0000-0000-0000-0000000000b2","role":"authenticated"}', true);
SELECT set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-0000000000b2', true);
SET LOCAL ROLE authenticated;

DO $$
BEGIN
  ASSERT NOT public.is_staff('00000000-0000-0000-0000-0000000000b2'::uuid), 'TEST FAILED: stranger must not be staff';
  ASSERT (SELECT count(*) FROM public.students) = 0, 'TEST FAILED: stranger can read students';
  ASSERT (SELECT count(*) FROM public.roll_number_assignments) = 0, 'TEST FAILED: stranger can read history';
  ASSERT (SELECT count(*) FROM public.my_staff_profile()) = 0, 'TEST FAILED: stranger should have no staff profile';
  ASSERT (SELECT count(*) FROM public.staff_allowlist) = 0, 'TEST FAILED: stranger can read the staff list';
END $$;
SELECT public._t_expect_error(
  $q$SELECT public.register_student('{"admission_number":"T-X","name":"X","course":"MCA","admission_date":"2099-07-01","semester":1}')$q$,
  'NOT_AUTHORIZED');
SELECT public._t_expect_error(
  $q$SELECT public.cancel_admission((SELECT id FROM public.students LIMIT 1))$q$, 'NOT_AUTHORIZED');
SELECT public._t_expect_error(
  $q$SELECT public.next_available_roll_number('MCA', '2099-07-01')$q$, 'NOT_AUTHORIZED');
SELECT public._t_expect_error(
  $q$INSERT INTO public.staff_allowlist (email, role) VALUES ('test-stranger@example.test', 'admin')$q$,
  'row-level security');
-- Settings can only be changed by an administrator: for a stranger zero rows are updated.
DO $$
DECLARE changed int;
BEGIN
  UPDATE public.roll_settings SET college_name = 'Hacked';
  GET DIAGNOSTICS changed = ROW_COUNT;
  ASSERT changed = 0, 'TEST FAILED: a non-admin changed the settings';
END $$;

-- ---- 9b. Not logged in at all (anonymous visitor) --------------------
RESET ROLE;
SELECT set_config('request.jwt.claims', '{"role":"anon"}', true);
SELECT set_config('request.jwt.claim.sub', '', true);
SET LOCAL ROLE anon;
SELECT public._t_expect_error($q$SELECT count(*) FROM public.students$q$, 'permission denied');
SELECT public._t_expect_error(
  $q$SELECT public.register_student('{"admission_number":"T-Y","name":"Y","course":"MCA","semester":1}')$q$,
  'permission denied');

-- ---- documents: the student-link functions work with a valid link only --
RESET ROLE;
DO $$
DECLARE tok uuid;
BEGIN
  SELECT upload_token INTO tok FROM public.students WHERE admission_number = 'T-005';
  SET LOCAL ROLE anon;
  ASSERT (public.student_portal_get(tok)->>'admission_number') = 'T-005', 'TEST FAILED: valid link should open the student page';
  ASSERT public.student_portal_get(gen_random_uuid()) IS NULL, 'TEST FAILED: unknown link must return nothing';
  RESET ROLE;
END $$;

ROLLBACK;

SELECT 'ALL DATABASE TESTS PASSED' AS result;
