CREATE OR REPLACE FUNCTION public.available_roll_numbers()
 RETURNS TABLE(roll_number integer)
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT g FROM generate_series(
    (SELECT start_number FROM public.roll_settings WHERE id = 1),
    COALESCE((SELECT MAX(roll_number) FROM public.students), 0)
  ) g
  WHERE NOT EXISTS (SELECT 1 FROM public.students st WHERE st.status = 'active' AND st.roll_number = g);
$function$;