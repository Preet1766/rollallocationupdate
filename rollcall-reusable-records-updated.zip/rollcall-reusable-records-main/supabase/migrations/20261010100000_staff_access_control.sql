-- =====================================================================
-- STAFF ACCESS CONTROL  (migration 1 of 3)
--
-- Problem being fixed:
--   Before this change any person who signed up on the portal was
--   automatically given the 'staff' role (claim_staff_role), so a stranger
--   could read and change every student record.
--
-- What this migration does:
--   1. Adds an approved-staff list (staff_allowlist). Only emails on this
--      list are staff. Everyone else can sign up but sees nothing.
--   2. Rewrites is_staff() / has_role() to read that list live, so removing
--      someone from the list stops their access immediately.
--   3. Removes claim_staff_role() (the self-service staff grant).
--   4. Makes 'admin' meaningful: only admins manage the list and settings.
--   5. Hides the profiles table from non-staff.
--   6. Seeds the first administrator.
--
-- IMPORTANT: the allow-list is only safe if the email address is really
-- owned by the person signing in. See README -> "Security checklist":
-- create the admin account first, then switch off public sign-ups.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. Approved staff list
-- ---------------------------------------------------------------------
CREATE TABLE public.staff_allowlist (
  email text PRIMARY KEY,
  role public.app_role NOT NULL DEFAULT 'staff',
  full_name text NOT NULL DEFAULT '',
  employee_id text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT staff_allowlist_email_normalised
    CHECK (email = lower(btrim(email)) AND email <> '')
);

ALTER TABLE public.staff_allowlist ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.staff_allowlist TO authenticated;
GRANT ALL ON public.staff_allowlist TO service_role;

COMMENT ON TABLE public.staff_allowlist IS
  'Emails approved for portal access. Role comes from this table. Managed by administrators.';

-- ---------------------------------------------------------------------
-- 2. Access checks now read the approved list (live, no copied roles)
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1
    FROM auth.users u
    JOIN public.staff_allowlist a ON a.email = lower(u.email)
    WHERE u.id = _user_id
      AND u.email_confirmed_at IS NOT NULL
      AND a.role = _role
  );
$$;

CREATE OR REPLACE FUNCTION public.is_staff(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1
    FROM auth.users u
    JOIN public.staff_allowlist a ON a.email = lower(u.email)
    WHERE u.id = _user_id
      AND u.email_confirmed_at IS NOT NULL
      AND a.role IN ('admin', 'staff')
  );
$$;

-- Who is signed in? Returns no row when the account is not approved.
CREATE OR REPLACE FUNCTION public.my_staff_profile()
RETURNS TABLE (
  user_id uuid,
  email text,
  role public.app_role,
  full_name text,
  employee_id text
)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT
    u.id,
    a.email,
    a.role,
    COALESCE(NULLIF(a.full_name, ''), NULLIF(p.name, ''), split_part(a.email, '@', 1)),
    a.employee_id
  FROM auth.users u
  JOIN public.staff_allowlist a ON a.email = lower(u.email)
  LEFT JOIN public.profiles p ON p.id = u.id
  WHERE u.id = auth.uid()
    AND u.email_confirmed_at IS NOT NULL;
$$;

-- Internal helper: the name + employee id stamped on every action a staff
-- member performs (registering, cancelling, verifying documents).
CREATE OR REPLACE FUNCTION public.staff_identity(_user_id uuid)
RETURNS TABLE (staff_name text, staff_employee_id text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT
    COALESCE(NULLIF(a.full_name, ''), NULLIF(p.name, ''), split_part(a.email, '@', 1)),
    a.employee_id
  FROM auth.users u
  JOIN public.staff_allowlist a ON a.email = lower(u.email)
  LEFT JOIN public.profiles p ON p.id = u.id
  WHERE u.id = _user_id
  LIMIT 1;
$$;

-- ---------------------------------------------------------------------
-- 3. Remove the self-service staff grant (the original hole)
-- ---------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.claim_staff_role();

-- user_roles is no longer consulted for any access decision. Rows left in it
-- (including any given to strangers before this fix) have no effect.
COMMENT ON TABLE public.user_roles IS
  'LEGACY - no longer used for access decisions. Access comes from staff_allowlist.';
REVOKE INSERT ON public.user_roles FROM authenticated;

-- ---------------------------------------------------------------------
-- 4. Only administrators manage the staff list and settings
-- ---------------------------------------------------------------------
CREATE POLICY "staff_allowlist_admin_all" ON public.staff_allowlist
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Never let the last administrator be removed, demoted or renamed.
CREATE OR REPLACE FUNCTION public.guard_last_admin()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF OLD.role = 'admin'
     AND (TG_OP = 'DELETE' OR NEW.role <> 'admin' OR NEW.email <> OLD.email) THEN
    IF NOT EXISTS (
      SELECT 1 FROM public.staff_allowlist
      WHERE role = 'admin' AND email <> OLD.email
    ) THEN
      RAISE EXCEPTION 'LAST_ADMIN';
    END IF;
  END IF;
  IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
  RETURN NEW;
END; $$;

CREATE TRIGGER staff_allowlist_guard
  BEFORE UPDATE OR DELETE ON public.staff_allowlist
  FOR EACH ROW EXECUTE FUNCTION public.guard_last_admin();

DROP POLICY IF EXISTS "settings_update_staff" ON public.roll_settings;
CREATE POLICY "settings_update_admin" ON public.roll_settings
  FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- ---------------------------------------------------------------------
-- 5. Staff names/emails are visible to staff only
-- ---------------------------------------------------------------------
DROP POLICY IF EXISTS "profiles_select_auth" ON public.profiles;
DROP POLICY IF EXISTS "profiles_insert_own" ON public.profiles;
DROP POLICY IF EXISTS "profiles_update_own" ON public.profiles;
REVOKE INSERT, UPDATE ON public.profiles FROM authenticated;
CREATE POLICY "profiles_select_staff" ON public.profiles
  FOR SELECT TO authenticated
  USING (public.is_staff(auth.uid()));

-- ---------------------------------------------------------------------
-- Function permissions (new functions are NOT open to everyone)
-- ---------------------------------------------------------------------
REVOKE ALL ON FUNCTION public.my_staff_profile() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.staff_identity(uuid) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.guard_last_admin() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.my_staff_profile() TO authenticated;
-- staff_identity and guard_last_admin are internal: only other database
-- functions / triggers use them.

-- ---------------------------------------------------------------------
-- 6. First administrator
-- ---------------------------------------------------------------------
INSERT INTO public.staff_allowlist (email, role, full_name)
VALUES ('lovepreet01706@gmail.com', 'admin', '')
ON CONFLICT (email) DO UPDATE SET role = 'admin';

-- ---------------------------------------------------------------------
-- CLEAN-UP CHECK (read-only, run it yourself after applying)
-- Lists every account in your project that is NOT on the approved list.
-- Anyone you do not recognise should be deleted in Supabase ->
-- Authentication -> Users. Nothing is deleted automatically.
--
--   SELECT u.id, u.email, u.created_at, u.last_sign_in_at
--   FROM auth.users u
--   LEFT JOIN public.staff_allowlist a ON a.email = lower(u.email)
--   WHERE a.email IS NULL
--   ORDER BY u.created_at;
-- ---------------------------------------------------------------------
