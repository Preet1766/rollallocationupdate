-- =====================================================================
-- STUDENT DOCUMENT UPLOAD + STAFF VERIFICATION  (migration 3 of 3)
--
-- How it works
--   * Every student has a private, hard-to-guess upload link
--     (students.upload_token). Staff share it with the student.
--   * The link lets the student upload ONLY their own documents and see the
--     status of each one. It opens nothing else in the portal.
--   * Files live in a PRIVATE storage bucket. Only staff can open them, using
--     short-lived signed links.
--   * Each document is Pending -> Verified or Rejected (with a reason).
--     The staff member's name + employee id is recorded on every review.
--
-- Documents: 10th report card, 12th report card, Aadhaar card, APAAR ID
-- (optional), RF-3/4 form, character certificate, migration certificate.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. Upload link per student
-- ---------------------------------------------------------------------
ALTER TABLE public.students
  ADD COLUMN upload_token uuid NOT NULL DEFAULT gen_random_uuid();
CREATE UNIQUE INDEX students_upload_token_key ON public.students (upload_token);

-- ---------------------------------------------------------------------
-- 2. Documents table (one current file per student per document type)
-- ---------------------------------------------------------------------
CREATE TABLE public.student_documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  doc_type text NOT NULL CHECK (doc_type IN (
    'tenth_marksheet', 'twelfth_marksheet', 'aadhaar', 'apaar_id',
    'rf_form', 'character_certificate', 'migration_certificate'
  )),
  file_path text NOT NULL,
  file_name text NOT NULL,
  mime_type text NOT NULL CHECK (mime_type IN ('application/pdf', 'image/jpeg', 'image/png')),
  size_bytes int NOT NULL CHECK (size_bytes > 0 AND size_bytes <= 5242880),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'verified', 'rejected')),
  reject_reason text,
  uploaded_via text NOT NULL CHECK (uploaded_via IN ('student', 'staff')),
  uploaded_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  uploaded_by_name text,
  uploaded_at timestamptz NOT NULL DEFAULT now(),
  reviewed_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  reviewed_by_name text,
  reviewed_by_staff_id text,
  reviewed_at timestamptz,
  UNIQUE (student_id, doc_type)
);
CREATE INDEX student_documents_student_idx ON public.student_documents (student_id);

ALTER TABLE public.student_documents ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.student_documents TO authenticated;
GRANT ALL ON public.student_documents TO service_role;
CREATE POLICY "student_documents_select_staff" ON public.student_documents
  FOR SELECT TO authenticated USING (public.is_staff(auth.uid()));
-- No insert/update/delete policies: all writes go through the functions below.

-- ---------------------------------------------------------------------
-- 3. Private storage bucket (PDF / JPG / PNG, 5 MB max)
-- ---------------------------------------------------------------------
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('student-docs', 'student-docs', false, 5242880,
        ARRAY['application/pdf', 'image/jpeg', 'image/png'])
ON CONFLICT (id) DO UPDATE
  SET public = false,
      file_size_limit = EXCLUDED.file_size_limit,
      allowed_mime_types = EXCLUDED.allowed_mime_types;

-- A file may be uploaded by someone holding a valid link only into the
-- folder named after that link:  <upload_token>/<file>
CREATE OR REPLACE FUNCTION public.student_upload_path_ok(_path text)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT coalesce(array_length(storage.foldername(_path), 1), 0) = 1
     AND EXISTS (
       SELECT 1 FROM public.students s
       WHERE s.status = 'active'
         AND s.upload_token::text = (storage.foldername(_path))[1]
     );
$$;

CREATE POLICY "student_docs_staff_read" ON storage.objects
  FOR SELECT TO authenticated
  USING (bucket_id = 'student-docs' AND public.is_staff(auth.uid()));

CREATE POLICY "student_docs_staff_upload" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'student-docs' AND public.is_staff(auth.uid()));

CREATE POLICY "student_docs_link_upload" ON storage.objects
  FOR INSERT TO anon, authenticated
  WITH CHECK (bucket_id = 'student-docs' AND public.student_upload_path_ok(name));
-- No update/delete policies: files cannot be altered or removed from the browser.

-- ---------------------------------------------------------------------
-- 4. Internal: record an uploaded file (shared by student + staff paths)
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public._save_document(
  _student_id uuid, _doc_type text, _path text, _file_name text,
  _mime text, _size int, _via text, _uid uuid, _uname text
) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  tok text;
  meta jsonb;
  real_mime text;
  real_size int;
BEGIN
  IF _doc_type NOT IN ('tenth_marksheet', 'twelfth_marksheet', 'aadhaar', 'apaar_id',
                       'rf_form', 'character_certificate', 'migration_certificate') THEN
    RAISE EXCEPTION 'INVALID_DOCUMENT_TYPE';
  END IF;

  SELECT s.upload_token::text INTO tok FROM public.students s WHERE s.id = _student_id;
  IF tok IS NULL OR left(_path, length(tok) + 1) <> tok || '/' THEN
    RAISE EXCEPTION 'INVALID_FILE_PATH';
  END IF;

  -- Trust the storage service's own record of the file, not the browser's claim.
  SELECT o.metadata INTO meta
  FROM storage.objects o
  WHERE o.bucket_id = 'student-docs' AND o.name = _path;
  IF NOT FOUND THEN RAISE EXCEPTION 'FILE_NOT_FOUND'; END IF;

  real_mime := coalesce(meta->>'mimetype', _mime);
  real_size := coalesce((meta->>'size')::int, _size);
  IF real_mime NOT IN ('application/pdf', 'image/jpeg', 'image/png') THEN
    RAISE EXCEPTION 'INVALID_FILE_TYPE';
  END IF;
  IF real_size IS NULL OR real_size <= 0 OR real_size > 5242880 THEN
    RAISE EXCEPTION 'FILE_TOO_LARGE';
  END IF;

  INSERT INTO public.student_documents (
    student_id, doc_type, file_path, file_name, mime_type, size_bytes,
    status, uploaded_via, uploaded_by, uploaded_by_name
  ) VALUES (
    _student_id, _doc_type, _path, left(coalesce(nullif(btrim(_file_name), ''), 'document'), 200),
    real_mime, real_size, 'pending', _via, _uid, _uname
  )
  ON CONFLICT (student_id, doc_type) DO UPDATE SET
    file_path = EXCLUDED.file_path,
    file_name = EXCLUDED.file_name,
    mime_type = EXCLUDED.mime_type,
    size_bytes = EXCLUDED.size_bytes,
    status = 'pending',
    reject_reason = NULL,
    uploaded_via = EXCLUDED.uploaded_via,
    uploaded_by = EXCLUDED.uploaded_by,
    uploaded_by_name = EXCLUDED.uploaded_by_name,
    uploaded_at = now(),
    reviewed_by = NULL,
    reviewed_by_name = NULL,
    reviewed_by_staff_id = NULL,
    reviewed_at = NULL;
END; $$;

-- ---------------------------------------------------------------------
-- 5. Student-facing functions (work with the upload link only, no login)
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.student_portal_get(_token uuid)
RETURNS jsonb LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT jsonb_build_object(
    'college_name', (SELECT rs.college_name FROM public.roll_settings rs WHERE rs.id = 1),
    'name', s.name,
    'admission_number', s.admission_number,
    'course', s.course,
    'documents', coalesce((
      SELECT jsonb_agg(jsonb_build_object(
        'doc_type', d.doc_type,
        'status', d.status,
        'reject_reason', d.reject_reason,
        'file_name', d.file_name,
        'uploaded_at', d.uploaded_at
      ))
      FROM public.student_documents d
      WHERE d.student_id = s.id
    ), '[]'::jsonb)
  )
  FROM public.students s
  WHERE s.upload_token = _token AND s.status = 'active';
$$;

CREATE OR REPLACE FUNCTION public.student_portal_register_document(
  _token uuid, _doc_type text, _path text, _file_name text, _mime text, _size int
) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  sid uuid;
  current_status text;
BEGIN
  SELECT s.id INTO sid
  FROM public.students s
  WHERE s.upload_token = _token AND s.status = 'active';
  IF sid IS NULL THEN RAISE EXCEPTION 'LINK_INVALID'; END IF;

  SELECT d.status INTO current_status
  FROM public.student_documents d
  WHERE d.student_id = sid AND d.doc_type = _doc_type;
  IF current_status = 'verified' THEN RAISE EXCEPTION 'DOCUMENT_LOCKED'; END IF;

  PERFORM public._save_document(sid, _doc_type, _path, _file_name, _mime, _size,
                                'student', NULL, NULL);
END; $$;

-- ---------------------------------------------------------------------
-- 6. Staff-facing functions
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.staff_register_document(
  _student_id uuid, _doc_type text, _path text, _file_name text, _mime text, _size int
) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  uid uuid := auth.uid();
  who_name text;
  who_id text;
BEGIN
  IF uid IS NULL OR NOT public.is_staff(uid) THEN RAISE EXCEPTION 'NOT_AUTHORIZED'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.students s WHERE s.id = _student_id) THEN
    RAISE EXCEPTION 'STUDENT_NOT_FOUND';
  END IF;

  SELECT i.staff_name, i.staff_employee_id INTO who_name, who_id
  FROM public.staff_identity(uid) i;

  PERFORM public._save_document(_student_id, _doc_type, _path, _file_name, _mime, _size,
                                'staff', uid, who_name);
END; $$;

CREATE OR REPLACE FUNCTION public.verify_document(_doc_id uuid, _approve boolean, _reason text DEFAULT NULL)
RETURNS public.student_documents LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  uid uuid := auth.uid();
  rec public.student_documents;
  who_name text;
  who_id text;
BEGIN
  IF uid IS NULL OR NOT public.is_staff(uid) THEN RAISE EXCEPTION 'NOT_AUTHORIZED'; END IF;
  IF NOT _approve AND coalesce(btrim(_reason), '') = '' THEN
    RAISE EXCEPTION 'REASON_REQUIRED';
  END IF;

  SELECT i.staff_name, i.staff_employee_id INTO who_name, who_id
  FROM public.staff_identity(uid) i;

  UPDATE public.student_documents SET
    status = CASE WHEN _approve THEN 'verified' ELSE 'rejected' END,
    reject_reason = CASE WHEN _approve THEN NULL ELSE btrim(_reason) END,
    reviewed_by = uid,
    reviewed_by_name = who_name,
    reviewed_by_staff_id = who_id,
    reviewed_at = now()
  WHERE id = _doc_id
  RETURNING * INTO rec;

  IF NOT FOUND THEN RAISE EXCEPTION 'DOCUMENT_NOT_FOUND'; END IF;
  RETURN rec;
END; $$;

-- Issue a fresh upload link (the old one stops working immediately).
CREATE OR REPLACE FUNCTION public.regenerate_upload_link(_student_id uuid)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  tok uuid;
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_staff(auth.uid()) THEN
    RAISE EXCEPTION 'NOT_AUTHORIZED';
  END IF;

  UPDATE public.students
     SET upload_token = gen_random_uuid()
   WHERE id = _student_id AND status = 'active'
  RETURNING upload_token INTO tok;

  IF tok IS NULL THEN RAISE EXCEPTION 'STUDENT_NOT_FOUND'; END IF;
  RETURN tok;
END; $$;

-- ---------------------------------------------------------------------
-- 7. Function permissions
-- ---------------------------------------------------------------------
REVOKE ALL ON FUNCTION public.student_upload_path_ok(text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public._save_document(uuid, text, text, text, text, int, text, uuid, text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.student_portal_get(uuid) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.student_portal_register_document(uuid, text, text, text, text, int) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.staff_register_document(uuid, text, text, text, text, int) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.verify_document(uuid, boolean, text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.regenerate_upload_link(uuid) FROM PUBLIC, anon, authenticated;

-- The storage upload rule is evaluated for the person uploading, so that role
-- needs to be able to call the path check.
GRANT EXECUTE ON FUNCTION public.student_upload_path_ok(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.student_portal_get(uuid) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.student_portal_register_document(uuid, text, text, text, text, int) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.staff_register_document(uuid, text, text, text, text, int) TO authenticated;
GRANT EXECUTE ON FUNCTION public.verify_document(uuid, boolean, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.regenerate_upload_link(uuid) TO authenticated;

-- ---------------------------------------------------------------------
-- 8. Visitors who are not logged in get no direct table access at all.
--    The student upload page only talks to the functions above.
-- ---------------------------------------------------------------------
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM anon;
