-- ROLES
CREATE TYPE public.app_role AS ENUM ('admin', 'staff');

CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL DEFAULT '',
  email text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "profiles_select_auth" ON public.profiles FOR SELECT TO authenticated USING (true);
CREATE POLICY "profiles_insert_own" ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
CREATE POLICY "profiles_update_own" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT, INSERT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "user_roles_select_own" ON public.user_roles FOR SELECT TO authenticated USING (user_id = auth.uid());

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role);
$$;

CREATE OR REPLACE FUNCTION public.is_staff(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role IN ('admin','staff'));
$$;

-- Any signed-in staff member is enrolled as 'staff' on first login by the app.
CREATE OR REPLACE FUNCTION public.claim_staff_role()
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.user_roles (user_id, role) VALUES (auth.uid(), 'staff')
  ON CONFLICT (user_id, role) DO NOTHING;
END;
$$;

-- STUDENTS
CREATE TABLE public.students (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admission_number text NOT NULL,
  name text NOT NULL,
  guardian_name text NOT NULL DEFAULT '',
  dob date,
  gender text NOT NULL DEFAULT 'Other',
  phone text NOT NULL DEFAULT '',
  email text NOT NULL DEFAULT '',
  address text NOT NULL DEFAULT '',
  course text NOT NULL,
  specialization text NOT NULL DEFAULT '',
  semester int NOT NULL DEFAULT 1 CHECK (semester BETWEEN 1 AND 12),
  academic_year text NOT NULL DEFAULT '',
  admission_date date NOT NULL DEFAULT current_date,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','cancelled')),
  roll_number int,
  cancelled_at timestamptz,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX students_admission_number_key ON public.students (lower(admission_number));
CREATE UNIQUE INDEX students_active_roll_key ON public.students (roll_number) WHERE status = 'active' AND roll_number IS NOT NULL;
CREATE INDEX students_status_idx ON public.students (status);
CREATE INDEX students_name_idx ON public.students (lower(name));

GRANT SELECT, INSERT, UPDATE ON public.students TO authenticated;
GRANT ALL ON public.students TO service_role;
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
CREATE POLICY "students_select_staff" ON public.students FOR SELECT TO authenticated USING (public.is_staff(auth.uid()));
CREATE POLICY "students_update_staff" ON public.students FOR UPDATE TO authenticated USING (public.is_staff(auth.uid())) WITH CHECK (public.is_staff(auth.uid()));

-- ROLL NUMBER ASSIGNMENTS
CREATE TABLE public.roll_number_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  roll_number int NOT NULL,
  assigned_at timestamptz NOT NULL DEFAULT now(),
  released_at timestamptz,
  status text NOT NULL DEFAULT 'assigned' CHECK (status IN ('assigned','released')),
  assigned_by uuid REFERENCES auth.users(id) ON DELETE SET NULL
);
CREATE INDEX rna_student_idx ON public.roll_number_assignments (student_id);
CREATE INDEX rna_roll_idx ON public.roll_number_assignments (roll_number);
GRANT SELECT ON public.roll_number_assignments TO authenticated;
GRANT ALL ON public.roll_number_assignments TO service_role;
ALTER TABLE public.roll_number_assignments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "rna_select_staff" ON public.roll_number_assignments FOR SELECT TO authenticated USING (public.is_staff(auth.uid()));

-- SETTINGS
CREATE TABLE public.roll_settings (
  id int PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  college_name text NOT NULL DEFAULT 'Sunrise College of Science & Commerce',
  prefix text NOT NULL DEFAULT 'BCA',
  separator text NOT NULL DEFAULT '-',
  padding int NOT NULL DEFAULT 3 CHECK (padding BETWEEN 1 AND 6),
  start_number int NOT NULL DEFAULT 1 CHECK (start_number >= 1),
  updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO public.roll_settings (id) VALUES (1);
GRANT SELECT, UPDATE ON public.roll_settings TO authenticated;
GRANT ALL ON public.roll_settings TO service_role;
ALTER TABLE public.roll_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "settings_select_staff" ON public.roll_settings FOR SELECT TO authenticated USING (public.is_staff(auth.uid()));
CREATE POLICY "settings_update_staff" ON public.roll_settings FOR UPDATE TO authenticated USING (public.is_staff(auth.uid())) WITH CHECK (public.is_staff(auth.uid()));

-- updated_at trigger
CREATE OR REPLACE FUNCTION public.touch_updated_at() RETURNS trigger
LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;
CREATE TRIGGER students_touch BEFORE UPDATE ON public.students FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- LOWEST AVAILABLE ROLL NUMBER
CREATE OR REPLACE FUNCTION public.next_available_roll_number()
RETURNS int LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE s int; n int;
BEGIN
  SELECT start_number INTO s FROM public.roll_settings WHERE id = 1;
  SELECT MIN(g) INTO n FROM generate_series(s, s + (SELECT count(*) FROM public.students WHERE status = 'active')::int) g
  WHERE NOT EXISTS (
    SELECT 1 FROM public.students st WHERE st.status = 'active' AND st.roll_number = g
  );
  RETURN n;
END; $$;

-- AVAILABLE (freed) ROLL NUMBERS BELOW THE HIGH-WATER MARK
CREATE OR REPLACE FUNCTION public.available_roll_numbers()
RETURNS TABLE (roll_number int) LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT g FROM generate_series(
    (SELECT start_number FROM public.roll_settings WHERE id = 1),
    COALESCE((SELECT MAX(roll_number) FROM public.students WHERE status = 'active'), 0)
  ) g
  WHERE NOT EXISTS (SELECT 1 FROM public.students st WHERE st.status = 'active' AND st.roll_number = g);
$$;

-- REGISTER STUDENT (atomic allocation)
CREATE OR REPLACE FUNCTION public.register_student(payload jsonb)
RETURNS public.students LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  uid uuid := auth.uid();
  roll int;
  rec public.students;
  adm text := trim(payload->>'admission_number');
BEGIN
  IF uid IS NULL OR NOT public.is_staff(uid) THEN
    RAISE EXCEPTION 'NOT_AUTHORIZED';
  END IF;
  IF adm IS NULL OR adm = '' THEN RAISE EXCEPTION 'ADMISSION_REQUIRED'; END IF;
  IF coalesce(trim(payload->>'name'),'') = '' THEN RAISE EXCEPTION 'NAME_REQUIRED'; END IF;
  IF coalesce(trim(payload->>'course'),'') = '' THEN RAISE EXCEPTION 'COURSE_REQUIRED'; END IF;
  IF EXISTS (SELECT 1 FROM public.students WHERE lower(admission_number) = lower(adm)) THEN
    RAISE EXCEPTION 'DUPLICATE_ADMISSION';
  END IF;

  -- serialize concurrent allocations
  PERFORM pg_advisory_xact_lock(hashtext('roll_number_allocation'));

  roll := public.next_available_roll_number();
  IF roll IS NULL THEN RAISE EXCEPTION 'NO_ROLL_AVAILABLE'; END IF;

  INSERT INTO public.students (
    admission_number, name, guardian_name, dob, gender, phone, email, address,
    course, specialization, semester, academic_year, admission_date, status, roll_number, created_by
  ) VALUES (
    adm,
    trim(payload->>'name'),
    coalesce(payload->>'guardian_name',''),
    nullif(payload->>'dob','')::date,
    coalesce(nullif(payload->>'gender',''),'Other'),
    coalesce(payload->>'phone',''),
    coalesce(payload->>'email',''),
    coalesce(payload->>'address',''),
    trim(payload->>'course'),
    coalesce(payload->>'specialization',''),
    coalesce(nullif(payload->>'semester','')::int, 1),
    coalesce(payload->>'academic_year',''),
    coalesce(nullif(payload->>'admission_date','')::date, current_date),
    'active', roll, uid
  ) RETURNING * INTO rec;

  INSERT INTO public.roll_number_assignments (student_id, roll_number, assigned_by)
  VALUES (rec.id, roll, uid);

  RETURN rec;
END; $$;

-- CANCEL ADMISSION
CREATE OR REPLACE FUNCTION public.cancel_admission(_student_id uuid)
RETURNS public.students LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE uid uuid := auth.uid(); rec public.students;
BEGIN
  IF uid IS NULL OR NOT public.is_staff(uid) THEN RAISE EXCEPTION 'NOT_AUTHORIZED'; END IF;
  SELECT * INTO rec FROM public.students WHERE id = _student_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'STUDENT_NOT_FOUND'; END IF;
  IF rec.status = 'cancelled' THEN RAISE EXCEPTION 'ALREADY_CANCELLED'; END IF;

  UPDATE public.roll_number_assignments
     SET status = 'released', released_at = now()
   WHERE student_id = _student_id AND status = 'assigned';

  UPDATE public.students
     SET status = 'cancelled', cancelled_at = now()
   WHERE id = _student_id
  RETURNING * INTO rec;

  RETURN rec;
END; $$;

REVOKE ALL ON FUNCTION public.register_student(jsonb) FROM public;
REVOKE ALL ON FUNCTION public.cancel_admission(uuid) FROM public;
GRANT EXECUTE ON FUNCTION public.register_student(jsonb) TO authenticated;
GRANT EXECUTE ON FUNCTION public.cancel_admission(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.next_available_roll_number() TO authenticated;
GRANT EXECUTE ON FUNCTION public.available_roll_numbers() TO authenticated;
GRANT EXECUTE ON FUNCTION public.claim_staff_role() TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_staff(uuid) TO authenticated;

-- DEMO SEED
INSERT INTO public.students (admission_number, name, guardian_name, dob, gender, phone, email, address, course, specialization, semester, academic_year, admission_date, status, roll_number) VALUES
('ADM001','Aarav Sharma','Rakesh Sharma','2004-03-12','Male','9876543210','aarav@example.com','12 MG Road, Pune','BCA','Web Development',1,'2024-2025','2024-07-01','active',1),
('ADM002','Priya Nair','Suresh Nair','2004-08-25','Female','9876543211','priya@example.com','8 Park Street, Kochi','BCA','Data Science',1,'2024-2025','2024-07-01','active',2),
('ADM003','Rahul Verma','Anil Verma','2003-11-02','Male','9876543212','rahul@example.com','5 Civil Lines, Jaipur','BCA','Cyber Security',3,'2024-2025','2024-07-02','active',3),
('ADM004','Sneha Patil','Mahesh Patil','2004-01-19','Female','9876543213','sneha@example.com','21 FC Road, Nashik','BCA','Web Development',3,'2024-2025','2024-07-02','active',4);

INSERT INTO public.roll_number_assignments (student_id, roll_number, assigned_at)
SELECT id, roll_number, created_at FROM public.students WHERE roll_number IS NOT NULL;