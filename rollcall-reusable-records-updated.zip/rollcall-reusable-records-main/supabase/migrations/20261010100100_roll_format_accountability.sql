-- =====================================================================
-- ROLL NUMBER FORMAT, STAFF ACCOUNTABILITY, SPECIALIZATIONS  (migration 2 of 3)
--
-- Roll number format (8 digits):  13 | YY | C | SSS
--   13  = fixed college prefix
--   YY  = last two digits of the admission year   (26 -> 2026)
--   C   = course digit                            (0 BCA, 1 BSc, 7 MCA)
--   SSS = serial inside that year + course group  (001 - 999)
-- Example: first BCA student admitted in 2026 -> 13260001
--
-- Serial numbers are counted separately for every (year, course) group.
-- When an admission is cancelled its number becomes free again and the
-- lowest free number in the SAME group is handed out next.
--
-- NOTE FOR EXISTING DATA: students already in the database are converted
-- to the new format (not deleted). Courses that are not offered any more
-- (BBA, B.Com, M.Com ...) cannot be converted - the migration stops with a
-- clear message if it finds such students. Delete or fix those test records
-- and run it again.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. Courses (the single place that decides the course digit)
--    To add a course later:
--      INSERT INTO public.courses (name, code, sort_order) VALUES ('BBA', 2, 4);
-- ---------------------------------------------------------------------
CREATE TABLE public.courses (
  name text PRIMARY KEY,
  code smallint NOT NULL UNIQUE CHECK (code BETWEEN 0 AND 9),
  active boolean NOT NULL DEFAULT true,
  sort_order int NOT NULL DEFAULT 0
);
INSERT INTO public.courses (name, code, sort_order) VALUES
  ('BCA', 0, 1),
  ('BSc', 1, 2),
  ('MCA', 7, 3);

ALTER TABLE public.courses ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.courses TO authenticated;
GRANT ALL ON public.courses TO service_role;
CREATE POLICY "courses_select_staff" ON public.courses
  FOR SELECT TO authenticated USING (public.is_staff(auth.uid()));

-- ---------------------------------------------------------------------
-- 2. Who did what (snapshot of name + employee id, plus the account UID)
-- ---------------------------------------------------------------------
ALTER TABLE public.students
  ADD COLUMN registered_by_name text,
  ADD COLUMN registered_by_staff_id text,
  ADD COLUMN cancelled_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN cancelled_by_name text,
  ADD COLUMN cancelled_by_staff_id text;

ALTER TABLE public.roll_number_assignments
  ADD COLUMN assigned_by_name text,
  ADD COLUMN assigned_by_staff_id text,
  ADD COLUMN released_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN released_by_name text,
  ADD COLUMN released_by_staff_id text;

-- ---------------------------------------------------------------------
-- 3. Convert existing records
-- ---------------------------------------------------------------------
UPDATE public.students SET course = 'BSc' WHERE course IN ('B.Sc IT', 'B.Sc', 'BSc IT');

DO $$
DECLARE bad text;
BEGIN
  SELECT string_agg(DISTINCT s.course, ', ') INTO bad
  FROM public.students s
  WHERE NOT EXISTS (SELECT 1 FROM public.courses c WHERE c.name = s.course);
  IF bad IS NOT NULL THEN
    RAISE EXCEPTION 'MIGRATION STOPPED: existing students belong to courses that are no longer offered (%). Delete or edit those test records, then run this migration again.', bad;
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.students s
    WHERE extract(year FROM s.admission_date) NOT BETWEEN 2000 AND 2099
  ) THEN
    RAISE EXCEPTION 'MIGRATION STOPPED: a student has an admission date outside 2000-2099.';
  END IF;

  IF EXISTS (
    SELECT 1
    FROM public.students s
    JOIN public.courses c ON c.name = s.course
    GROUP BY extract(year FROM s.admission_date), c.code
    HAVING count(*) > 999
  ) THEN
    RAISE EXCEPTION 'MIGRATION STOPPED: more than 999 students in one year + course group.';
  END IF;
END $$;

-- Give every existing student (active and cancelled) a new-format number in
-- admission order. Cancelled students keep theirs as history, so their
-- numbers are immediately free for reuse - exactly like new cancellations.
WITH numbered AS (
  SELECT
    s.id,
    13000000
      + (extract(year FROM s.admission_date)::int % 100) * 10000
      + c.code * 1000
      + row_number() OVER (
          PARTITION BY extract(year FROM s.admission_date)::int, c.code
          ORDER BY s.created_at, s.id
        ) AS new_roll
  FROM public.students s
  JOIN public.courses c ON c.name = s.course
)
UPDATE public.students s
SET roll_number = n.new_roll::int
FROM numbered n
WHERE n.id = s.id;

UPDATE public.roll_number_assignments a
SET roll_number = s.roll_number
FROM public.students s
WHERE s.id = a.student_id AND s.roll_number IS NOT NULL;

-- Specializations: only three are allowed from now on.
UPDATE public.students SET specialization = CASE
  WHEN specialization IN ('Artificial Intelligence',
                          'Artificial Intelligence & Machine Learning',
                          'AI & ML') THEN 'Artificial Intelligence & Machine Learning'
  WHEN specialization = 'Data Science' THEN 'Data Science'
  ELSE 'Regular'
END;

-- ---------------------------------------------------------------------
-- 4. Constraints that protect the new rules
-- ---------------------------------------------------------------------
ALTER TABLE public.students
  ADD CONSTRAINT students_roll_format
    CHECK (roll_number IS NULL
           OR (roll_number BETWEEN 13000001 AND 13999999 AND roll_number % 1000 <> 0)),
  ADD CONSTRAINT students_specialization_check
    CHECK (specialization IN ('Artificial Intelligence & Machine Learning',
                              'Data Science',
                              'Regular')),
  ADD CONSTRAINT students_course_fkey
    FOREIGN KEY (course) REFERENCES public.courses(name) ON UPDATE CASCADE;
ALTER TABLE public.students ALTER COLUMN specialization SET DEFAULT 'Regular';

ALTER TABLE public.roll_number_assignments
  ADD CONSTRAINT rna_roll_format
    CHECK (roll_number BETWEEN 13000001 AND 13999999 AND roll_number % 1000 <> 0);

-- ---------------------------------------------------------------------
-- 5. Settings: the roll format is fixed now, only the college name stays
-- ---------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.next_available_roll_number();
ALTER TABLE public.roll_settings
  DROP COLUMN prefix,
  DROP COLUMN separator,
  DROP COLUMN padding,
  DROP COLUMN start_number;

-- ---------------------------------------------------------------------
-- 6. Allocation helpers
-- ---------------------------------------------------------------------

-- First number of a (year, course) group:  13 YY C 000
CREATE OR REPLACE FUNCTION public.roll_base(_course text, _admission_date date)
RETURNS int LANGUAGE plpgsql STABLE SET search_path = public AS $$
DECLARE
  yr int;
  course_code smallint;
BEGIN
  IF _admission_date IS NULL THEN RAISE EXCEPTION 'INVALID_ADMISSION_DATE'; END IF;
  yr := extract(year FROM _admission_date)::int;
  IF yr < 2000 OR yr > 2099 THEN RAISE EXCEPTION 'INVALID_ADMISSION_DATE'; END IF;

  SELECT c.code INTO course_code
  FROM public.courses c
  WHERE c.name = _course AND c.active;
  IF course_code IS NULL THEN RAISE EXCEPTION 'INVALID_COURSE'; END IF;

  RETURN 13000000 + (yr % 100) * 10000 + course_code * 1000;
END; $$;

-- Lowest free number inside one group, or NULL when all 999 are taken.
-- With n active students a free number always exists in serials 1..n+1,
-- so the search never needs to look further than that.
-- (Deliberately VOLATILE so it always sees the latest committed rows.)
CREATE OR REPLACE FUNCTION public.next_free_roll(_base int)
RETURNS int LANGUAGE plpgsql SET search_path = public AS $$
DECLARE
  used int;
  found_roll int;
BEGIN
  SELECT count(*) INTO used
  FROM public.students st
  WHERE st.status = 'active'
    AND st.roll_number BETWEEN _base + 1 AND _base + 999;

  SELECT MIN(g) INTO found_roll
  FROM generate_series(_base + 1, _base + LEAST(used + 1, 999)) g
  WHERE NOT EXISTS (
    SELECT 1 FROM public.students st
    WHERE st.status = 'active' AND st.roll_number = g
  );

  RETURN found_roll;
END; $$;

-- The number the next registration would receive (used for the preview on
-- the registration form; the real number is decided again at save time).
CREATE OR REPLACE FUNCTION public.next_available_roll_number(_course text, _admission_date date)
RETURNS int LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_staff(auth.uid()) THEN
    RAISE EXCEPTION 'NOT_AUTHORIZED';
  END IF;
  RETURN public.next_free_roll(public.roll_base(_course, _admission_date));
END; $$;

-- Freed numbers (below the highest number ever issued in each group).
CREATE OR REPLACE FUNCTION public.available_roll_numbers()
RETURNS TABLE (roll_number int)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT g
  FROM (
    SELECT (st.roll_number / 1000) AS grp, max(st.roll_number) AS top_roll
    FROM public.students st
    WHERE st.roll_number IS NOT NULL
    GROUP BY st.roll_number / 1000
  ) t,
  LATERAL generate_series(t.grp * 1000 + 1, t.top_roll) g
  WHERE public.is_staff(auth.uid())
    AND NOT EXISTS (
      SELECT 1 FROM public.students s2
      WHERE s2.status = 'active' AND s2.roll_number = g
    )
  ORDER BY g;
$$;

-- ---------------------------------------------------------------------
-- 7. Backend validation shared by register + update
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.check_student_fields(
  _phone text, _email text, _semester int, _specialization text, _dob date
) RETURNS void LANGUAGE plpgsql STABLE SET search_path = public AS $$
BEGIN
  IF coalesce(btrim(_phone), '') <> '' AND btrim(_phone) !~ '^[+]?[0-9 -]{7,15}$' THEN
    RAISE EXCEPTION 'INVALID_PHONE';
  END IF;
  IF coalesce(btrim(_email), '') <> ''
     AND btrim(_email) !~ '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]{2,}$' THEN
    RAISE EXCEPTION 'INVALID_EMAIL';
  END IF;
  IF _semester IS NULL OR _semester < 1 OR _semester > 8 THEN
    RAISE EXCEPTION 'INVALID_SEMESTER';
  END IF;
  IF _specialization IS NULL OR _specialization NOT IN (
       'Artificial Intelligence & Machine Learning', 'Data Science', 'Regular') THEN
    RAISE EXCEPTION 'INVALID_SPECIALIZATION';
  END IF;
  IF _dob IS NOT NULL AND _dob >= current_date THEN
    RAISE EXCEPTION 'INVALID_DOB';
  END IF;
END; $$;

-- ---------------------------------------------------------------------
-- 8. Register a student (allocation + history, all-or-nothing)
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.register_student(payload jsonb)
RETURNS public.students LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  uid uuid := auth.uid();
  adm text := btrim(payload->>'admission_number');
  crs text := btrim(payload->>'course');
  adm_date date;
  dob_v date;
  spec text;
  sem int;
  grp_base int;
  new_roll int;
  who_name text;
  who_id text;
  rec public.students;
BEGIN
  IF uid IS NULL OR NOT public.is_staff(uid) THEN RAISE EXCEPTION 'NOT_AUTHORIZED'; END IF;
  IF adm IS NULL OR adm = '' THEN RAISE EXCEPTION 'ADMISSION_REQUIRED'; END IF;
  IF coalesce(btrim(payload->>'name'), '') = '' THEN RAISE EXCEPTION 'NAME_REQUIRED'; END IF;
  IF coalesce(crs, '') = '' THEN RAISE EXCEPTION 'COURSE_REQUIRED'; END IF;

  adm_date := coalesce(nullif(payload->>'admission_date', '')::date, current_date);
  dob_v := nullif(payload->>'dob', '')::date;
  spec := coalesce(nullif(btrim(payload->>'specialization'), ''), 'Regular');
  sem := coalesce(nullif(payload->>'semester', '')::int, 1);
  PERFORM public.check_student_fields(payload->>'phone', payload->>'email', sem, spec, dob_v);

  -- One registration at a time while numbers are handed out.
  PERFORM pg_advisory_xact_lock(hashtext('roll_number_allocation'));

  IF EXISTS (SELECT 1 FROM public.students WHERE lower(admission_number) = lower(adm)) THEN
    RAISE EXCEPTION 'DUPLICATE_ADMISSION';
  END IF;

  grp_base := public.roll_base(crs, adm_date);
  new_roll := public.next_free_roll(grp_base);
  IF new_roll IS NULL THEN RAISE EXCEPTION 'NO_ROLL_AVAILABLE'; END IF;

  SELECT i.staff_name, i.staff_employee_id INTO who_name, who_id
  FROM public.staff_identity(uid) i;

  INSERT INTO public.students (
    admission_number, name, guardian_name, dob, gender, phone, email, address,
    course, specialization, semester, academic_year, admission_date,
    status, roll_number, created_by, registered_by_name, registered_by_staff_id
  ) VALUES (
    adm,
    btrim(payload->>'name'),
    coalesce(payload->>'guardian_name', ''),
    dob_v,
    coalesce(nullif(payload->>'gender', ''), 'Other'),
    coalesce(btrim(payload->>'phone'), ''),
    coalesce(btrim(payload->>'email'), ''),
    coalesce(payload->>'address', ''),
    crs,
    spec,
    sem,
    coalesce(payload->>'academic_year', ''),
    adm_date,
    'active', new_roll, uid, who_name, who_id
  ) RETURNING * INTO rec;

  INSERT INTO public.roll_number_assignments (
    student_id, roll_number, assigned_by, assigned_by_name, assigned_by_staff_id
  ) VALUES (rec.id, new_roll, uid, who_name, who_id);

  RETURN rec;
END; $$;

-- ---------------------------------------------------------------------
-- 9. Edit a student (replaces direct table updates)
--    Locked after registration: course, admission date, roll number, status.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.update_student(_student_id uuid, payload jsonb)
RETURNS public.students LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  uid uuid := auth.uid();
  cur public.students;
  rec public.students;
  new_adm text;
  new_name text;
  new_dob date;
  new_sem int;
  new_spec text;
  new_phone text;
  new_email text;
BEGIN
  IF uid IS NULL OR NOT public.is_staff(uid) THEN RAISE EXCEPTION 'NOT_AUTHORIZED'; END IF;

  SELECT * INTO cur FROM public.students WHERE id = _student_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'STUDENT_NOT_FOUND'; END IF;
  IF cur.status <> 'active' THEN RAISE EXCEPTION 'CANCELLED_READONLY'; END IF;

  IF (payload ? 'roll_number') OR (payload ? 'status')
     OR (payload ? 'course' AND payload->>'course' IS DISTINCT FROM cur.course)
     OR (payload ? 'admission_date'
         AND nullif(payload->>'admission_date', '')::date IS DISTINCT FROM cur.admission_date) THEN
    RAISE EXCEPTION 'LOCKED_FIELD';
  END IF;

  new_adm := CASE WHEN payload ? 'admission_number' THEN btrim(payload->>'admission_number') ELSE cur.admission_number END;
  new_name := CASE WHEN payload ? 'name' THEN btrim(payload->>'name') ELSE cur.name END;
  new_dob := CASE WHEN payload ? 'dob' THEN nullif(payload->>'dob', '')::date ELSE cur.dob END;
  new_sem := CASE WHEN payload ? 'semester' THEN nullif(payload->>'semester', '')::int ELSE cur.semester END;
  new_spec := CASE WHEN payload ? 'specialization' THEN nullif(btrim(payload->>'specialization'), '') ELSE cur.specialization END;
  new_phone := CASE WHEN payload ? 'phone' THEN coalesce(btrim(payload->>'phone'), '') ELSE cur.phone END;
  new_email := CASE WHEN payload ? 'email' THEN coalesce(btrim(payload->>'email'), '') ELSE cur.email END;

  IF coalesce(new_adm, '') = '' THEN RAISE EXCEPTION 'ADMISSION_REQUIRED'; END IF;
  IF coalesce(new_name, '') = '' THEN RAISE EXCEPTION 'NAME_REQUIRED'; END IF;
  IF lower(new_adm) <> lower(cur.admission_number) AND EXISTS (
       SELECT 1 FROM public.students s
       WHERE lower(s.admission_number) = lower(new_adm) AND s.id <> cur.id) THEN
    RAISE EXCEPTION 'DUPLICATE_ADMISSION';
  END IF;

  PERFORM public.check_student_fields(new_phone, new_email, new_sem, new_spec, new_dob);

  UPDATE public.students SET
    admission_number = new_adm,
    name = new_name,
    guardian_name = CASE WHEN payload ? 'guardian_name' THEN coalesce(payload->>'guardian_name', '') ELSE guardian_name END,
    dob = new_dob,
    gender = CASE WHEN payload ? 'gender' THEN coalesce(nullif(payload->>'gender', ''), 'Other') ELSE gender END,
    phone = new_phone,
    email = new_email,
    address = CASE WHEN payload ? 'address' THEN coalesce(payload->>'address', '') ELSE address END,
    specialization = new_spec,
    semester = new_sem,
    academic_year = CASE WHEN payload ? 'academic_year' THEN coalesce(payload->>'academic_year', '') ELSE academic_year END
  WHERE id = cur.id
  RETURNING * INTO rec;

  RETURN rec;
END; $$;

-- ---------------------------------------------------------------------
-- 10. Cancel an admission (records who cancelled it)
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.cancel_admission(_student_id uuid)
RETURNS public.students LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  uid uuid := auth.uid();
  rec public.students;
  who_name text;
  who_id text;
BEGIN
  IF uid IS NULL OR NOT public.is_staff(uid) THEN RAISE EXCEPTION 'NOT_AUTHORIZED'; END IF;

  SELECT * INTO rec FROM public.students WHERE id = _student_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'STUDENT_NOT_FOUND'; END IF;
  IF rec.status = 'cancelled' THEN RAISE EXCEPTION 'ALREADY_CANCELLED'; END IF;

  SELECT i.staff_name, i.staff_employee_id INTO who_name, who_id
  FROM public.staff_identity(uid) i;

  UPDATE public.roll_number_assignments
     SET status = 'released',
         released_at = now(),
         released_by = uid,
         released_by_name = who_name,
         released_by_staff_id = who_id
   WHERE student_id = _student_id AND status = 'assigned';

  UPDATE public.students
     SET status = 'cancelled',
         cancelled_at = now(),
         cancelled_by = uid,
         cancelled_by_name = who_name,
         cancelled_by_staff_id = who_id
   WHERE id = _student_id
  RETURNING * INTO rec;

  RETURN rec;
END; $$;

-- ---------------------------------------------------------------------
-- 11. Staff can no longer write to the students table directly.
--     Everything goes through the functions above, so roll numbers,
--     status and history cannot be changed from the browser.
-- ---------------------------------------------------------------------
DROP POLICY IF EXISTS "students_update_staff" ON public.students;
REVOKE INSERT, UPDATE ON public.students FROM authenticated;
REVOKE INSERT, UPDATE, DELETE ON public.roll_number_assignments FROM authenticated;

-- ---------------------------------------------------------------------
-- 12. Function permissions
-- ---------------------------------------------------------------------
REVOKE ALL ON FUNCTION public.roll_base(text, date) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.next_free_roll(int) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.check_student_fields(text, text, int, text, date) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.next_available_roll_number(text, date) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.update_student(uuid, jsonb) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.register_student(jsonb) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.cancel_admission(uuid) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.available_roll_numbers() FROM PUBLIC, anon, authenticated;

GRANT EXECUTE ON FUNCTION public.next_available_roll_number(text, date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.update_student(uuid, jsonb) TO authenticated;
GRANT EXECUTE ON FUNCTION public.register_student(jsonb) TO authenticated;
GRANT EXECUTE ON FUNCTION public.cancel_admission(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.available_roll_numbers() TO authenticated;
-- roll_base, next_free_roll and check_student_fields are internal helpers.
