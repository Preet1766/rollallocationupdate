REVOKE ALL ON FUNCTION public.register_student(jsonb) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.cancel_admission(uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.next_available_roll_number() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.available_roll_numbers() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.claim_staff_role() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.is_staff(uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.touch_updated_at() FROM PUBLIC, anon, authenticated;

GRANT EXECUTE ON FUNCTION public.register_student(jsonb) TO authenticated;
GRANT EXECUTE ON FUNCTION public.cancel_admission(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.next_available_roll_number() TO authenticated;
GRANT EXECUTE ON FUNCTION public.available_roll_numbers() TO authenticated;
GRANT EXECUTE ON FUNCTION public.claim_staff_role() TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_staff(uuid) TO authenticated;